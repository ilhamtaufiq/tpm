-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: tpm_db
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absensi`
--

DROP TABLE IF EXISTS `absensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `absensi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `karyawan_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('HADIR','IZIN','SAKIT','ALPHA','CUTI','SETENGAH_HARI') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HADIR',
  `jam_masuk` time DEFAULT NULL,
  `jam_keluar` time DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_absensi_karyawan_tanggal` (`karyawan_id`,`tanggal`),
  KEY `ix_absensi_karyawan_id` (`karyawan_id`),
  KEY `ix_absensi_tanggal` (`tanggal`),
  CONSTRAINT `absensi_ibfk_1` FOREIGN KEY (`karyawan_id`) REFERENCES `karyawan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absensi`
--

LOCK TABLES `absensi` WRITE;
/*!40000 ALTER TABLE `absensi` DISABLE KEYS */;
/*!40000 ALTER TABLE `absensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('e2f3g4h5i6j7');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `armada_jasa_angkut`
--

DROP TABLE IF EXISTS `armada_jasa_angkut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `armada_jasa_angkut` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nopol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_armada_jasa_angkut_nopol` (`nopol`),
  KEY `nama` (`nama`),
  KEY `ix_armada_jasa_angkut_nama` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `armada_jasa_angkut`
--

LOCK TABLES `armada_jasa_angkut` WRITE;
/*!40000 ALTER TABLE `armada_jasa_angkut` DISABLE KEYS */;
INSERT INTO `armada_jasa_angkut` VALUES (1,'Truck','F112Z','Dump Tricl',1,'','2026-02-16 10:20:26','2026-02-16 10:20:26',NULL);
/*!40000 ALTER TABLE `armada_jasa_angkut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aset`
--

DROP TABLE IF EXISTS `aset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` enum('KENDARAAN','PERALATAN','BANGUNAN','TANAH','ELECTRONIC','LAINNYA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_beli` date NOT NULL,
  `harga_beli` decimal(15,2) NOT NULL,
  `nilai_residu` decimal(15,2) NOT NULL,
  `umur_ekonomis` int NOT NULL,
  `status` enum('AKTIF','RUSAK','DIJUAL','HILANG') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_aset_kode` (`kode`),
  KEY `created_by` (`created_by`),
  KEY `ix_aset_nama` (`nama`),
  CONSTRAINT `aset_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aset`
--

LOCK TABLES `aset` WRITE;
/*!40000 ALTER TABLE `aset` DISABLE KEYS */;
/*!40000 ALTER TABLE `aset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_vehicles`
--

DROP TABLE IF EXISTS `customer_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `plat_nomor` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `ix_customer_vehicles_plat_nomor` (`plat_nomor`),
  CONSTRAINT `customer_vehicles_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_vehicles`
--

LOCK TABLES `customer_vehicles` WRITE;
/*!40000 ALTER TABLE `customer_vehicles` DISABLE KEYS */;
INSERT INTO `customer_vehicles` VALUES (1,1,'F11A','Avanza','','2026-02-03 18:24:55','2026-02-03 18:24:55'),(2,2,'F22Z','Avanza','','2026-02-03 18:25:13','2026-02-03 18:25:13'),(5,5,'A 1111 RR','CANTER 125PS','','2026-02-10 11:37:58','2026-02-10 11:37:58'),(6,4,'F 1111 AA','RINO 130HT','','2026-02-10 11:39:20','2026-02-10 11:39:20'),(7,6,'W 1111 AA','RINO EURO 4','','2026-02-12 09:28:32','2026-02-12 09:28:32'),(8,7,'W 4444 DD','RINO 130HT','','2026-02-12 09:29:04','2026-02-12 09:29:04'),(9,8,'F 1111 SV','RINO 130HT','','2026-02-14 09:17:01','2026-02-14 09:17:01');
/*!40000 ALTER TABLE `customer_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `kota` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telepon` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `npwp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_customers_kode` (`kode`),
  KEY `ix_customers_nama` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'CUS26010001','Ilham','perorangan','Cianjur','Cianjur','000000','sds@gmail.com',NULL,NULL,'2026-01-31 11:21:05','2026-02-04 07:39:22','2026-02-04 00:39:22'),(2,'CUS26020001','Pehul ','perorangan','Cianjur ','Cianjur ','000000000','pehul@gmail.com',NULL,NULL,'2026-02-02 10:31:11','2026-02-04 07:39:27','2026-02-04 00:39:27'),(3,'CUS26020002','Olobor','perorangan','Cianjur','Cianjur','00000',NULL,NULL,NULL,'2026-02-10 11:08:35','2026-02-10 11:08:35',NULL),(4,'CUS26020003','DAVIRA','perorangan','','CIANJUR','',NULL,NULL,NULL,'2026-02-10 11:36:37','2026-02-10 11:39:20',NULL),(5,'CUS26020004','AKAS ALAM','perusahaan','','CIANJUR','',NULL,NULL,NULL,'2026-02-10 11:37:05','2026-02-10 11:37:58',NULL),(6,'CUS26020005','KWSG','perusahaan','','CIANJUR','',NULL,NULL,NULL,'2026-02-12 09:28:32','2026-02-12 09:28:32',NULL),(7,'CUS26020006','KWSG ','perusahaan','','CIANJUR','',NULL,NULL,NULL,'2026-02-12 09:29:04','2026-02-12 09:29:04',NULL),(8,'CUS26020007','HJ DADAN','perorangan','CIANJUR','','',NULL,NULL,NULL,'2026-02-14 09:17:01','2026-02-14 09:17:01',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_pembelian_spare_parts`
--

DROP TABLE IF EXISTS `detail_pembelian_spare_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_pembelian_spare_parts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pembelian_id` int NOT NULL,
  `spare_part_id` int NOT NULL,
  `qty` int NOT NULL,
  `harga_satuan` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pembelian_id` (`pembelian_id`),
  KEY `spare_part_id` (`spare_part_id`),
  CONSTRAINT `detail_pembelian_spare_parts_ibfk_1` FOREIGN KEY (`pembelian_id`) REFERENCES `pembelian_spare_parts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `detail_pembelian_spare_parts_ibfk_2` FOREIGN KEY (`spare_part_id`) REFERENCES `spare_parts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_pembelian_spare_parts`
--

LOCK TABLES `detail_pembelian_spare_parts` WRITE;
/*!40000 ALTER TABLE `detail_pembelian_spare_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `detail_pembelian_spare_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_transaksi_services`
--

DROP TABLE IF EXISTS `detail_transaksi_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_transaksi_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaksi_id` int NOT NULL,
  `nama_jasa` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `harga` decimal(15,2) NOT NULL,
  `qty` int NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaksi_id` (`transaksi_id`),
  CONSTRAINT `detail_transaksi_services_ibfk_1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi_penjualan_bengkel` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_transaksi_services`
--

LOCK TABLES `detail_transaksi_services` WRITE;
/*!40000 ALTER TABLE `detail_transaksi_services` DISABLE KEYS */;
INSERT INTO `detail_transaksi_services` VALUES (105,112,'JASA STEL REM 2RD',NULL,50000.00,1,50000.00);
/*!40000 ALTER TABLE `detail_transaksi_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_transaksi_spare_parts`
--

DROP TABLE IF EXISTS `detail_transaksi_spare_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_transaksi_spare_parts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaksi_id` int NOT NULL,
  `spare_part_id` int NOT NULL,
  `qty` int NOT NULL,
  `harga_beli` decimal(15,2) NOT NULL,
  `harga_jual` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `spare_part_id` (`spare_part_id`),
  KEY `transaksi_id` (`transaksi_id`),
  CONSTRAINT `detail_transaksi_spare_parts_ibfk_1` FOREIGN KEY (`spare_part_id`) REFERENCES `spare_parts` (`id`),
  CONSTRAINT `detail_transaksi_spare_parts_ibfk_2` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi_penjualan_bengkel` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_transaksi_spare_parts`
--

LOCK TABLES `detail_transaksi_spare_parts` WRITE;
/*!40000 ALTER TABLE `detail_transaksi_spare_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `detail_transaksi_spare_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hutang_usaha`
--

DROP TABLE IF EXISTS `hutang_usaha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hutang_usaha` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_hutang` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `sumber` enum('PEMBELIAN_PART','PEMBELIAN_MOBIL','LAINNYA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `referensi_id` int DEFAULT NULL,
  `nomor_referensi` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int DEFAULT NULL,
  `nama_kreditur` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telepon_kreditur` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_kreditur` text COLLATE utf8mb4_unicode_ci,
  `nominal_hutang` decimal(15,2) NOT NULL,
  `total_dibayar` decimal(15,2) NOT NULL,
  `sisa_hutang` decimal(15,2) NOT NULL,
  `tanggal_jatuh_tempo` date DEFAULT NULL,
  `tanggal_lunas` date DEFAULT NULL,
  `status` enum('BELUM_LUNAS','LUNAS','SEBAGIAN','BATAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BELUM_LUNAS',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_hutang_usaha_nomor_hutang` (`nomor_hutang`),
  KEY `created_by` (`created_by`),
  KEY `ix_hutang_usaha_supplier_id` (`supplier_id`),
  KEY `ix_hutang_usaha_tanggal` (`tanggal`),
  CONSTRAINT `hutang_usaha_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `hutang_usaha_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hutang_usaha`
--

LOCK TABLES `hutang_usaha` WRITE;
/*!40000 ALTER TABLE `hutang_usaha` DISABLE KEYS */;
/*!40000 ALTER TABLE `hutang_usaha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investor_disbursement_detail`
--

DROP TABLE IF EXISTS `investor_disbursement_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investor_disbursement_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaksi_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `transaksi_id` (`transaksi_id`),
  CONSTRAINT `investor_disbursement_detail_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `investor_disbursement_detail_ibfk_2` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi_penjualan_mobil` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investor_disbursement_detail`
--

LOCK TABLES `investor_disbursement_detail` WRITE;
/*!40000 ALTER TABLE `investor_disbursement_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `investor_disbursement_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jasa_angkut_biaya_lainnya`
--

DROP TABLE IF EXISTS `jasa_angkut_biaya_lainnya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jasa_angkut_biaya_lainnya` (
  `id` int NOT NULL AUTO_INCREMENT,
  `muatan_id` int DEFAULT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `armada_id` int DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `muatan_id` (`muatan_id`),
  KEY `armada_id` (`armada_id`),
  KEY `ix_jasa_angkut_biaya_lainnya_tanggal` (`tanggal`),
  CONSTRAINT `jasa_angkut_biaya_lainnya_ibfk_1` FOREIGN KEY (`muatan_id`) REFERENCES `muatan_jasa_angkut` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jasa_angkut_biaya_lainnya_ibfk_2` FOREIGN KEY (`armada_id`) REFERENCES `armada_jasa_angkut` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jasa_angkut_biaya_lainnya`
--

LOCK TABLES `jasa_angkut_biaya_lainnya` WRITE;
/*!40000 ALTER TABLE `jasa_angkut_biaya_lainnya` DISABLE KEYS */;
/*!40000 ALTER TABLE `jasa_angkut_biaya_lainnya` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jasa_angkut_part_service`
--

DROP TABLE IF EXISTS `jasa_angkut_part_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jasa_angkut_part_service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `muatan_id` int DEFAULT NULL,
  `tanggal` date NOT NULL,
  `tipe` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL,
  `harga_satuan` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `armada_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `muatan_id` (`muatan_id`),
  KEY `armada_id` (`armada_id`),
  CONSTRAINT `jasa_angkut_part_service_ibfk_1` FOREIGN KEY (`muatan_id`) REFERENCES `muatan_jasa_angkut` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jasa_angkut_part_service_ibfk_2` FOREIGN KEY (`armada_id`) REFERENCES `armada_jasa_angkut` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jasa_angkut_part_service`
--

LOCK TABLES `jasa_angkut_part_service` WRITE;
/*!40000 ALTER TABLE `jasa_angkut_part_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `jasa_angkut_part_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jasa_servis`
--

DROP TABLE IF EXISTS `jasa_servis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jasa_servis` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `harga` decimal(15,2) NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_jasa_servis_nama` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jasa_servis`
--

LOCK TABLES `jasa_servis` WRITE;
/*!40000 ALTER TABLE `jasa_servis` DISABLE KEYS */;
INSERT INTO `jasa_servis` VALUES (1,'Ganti Oli','Servis',50000.00,'','2026-02-03 17:50:26','2026-02-09 22:46:42','2026-02-09 15:46:42'),(2,'Ganti Ban','Servis',50000000.00,'','2026-02-07 10:09:34','2026-02-09 22:46:38','2026-02-09 15:46:39'),(3,'Ganti Oli','Servis',50000.00,'tes','2026-02-09 22:47:05','2026-02-10 10:12:45','2026-02-10 03:12:45'),(4,'JASA STEL REM 2RD','Servis',50000.00,'-','2026-02-10 10:13:26','2026-02-10 10:13:26',NULL),(5,'JASA SERVICE REM 4RD DPN BLK','Servis',250000.00,'-','2026-02-10 10:13:51','2026-02-10 10:13:51',NULL),(6,'JASA BONGKAR/P GARDAN','Servis',500000.00,'','2026-02-11 11:00:41','2026-02-11 11:00:41',NULL),(7,'JASA GANTI LAHER RODA','Servis',50000.00,'','2026-02-14 09:18:11','2026-02-14 09:18:11',NULL);
/*!40000 ALTER TABLE `jasa_servis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `karyawan`
--

DROP TABLE IF EXISTS `karyawan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `karyawan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jabatan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `telepon` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `tanggal_bergabung` date NOT NULL,
  `tanggal_keluar` date DEFAULT NULL,
  `gaji_pokok` decimal(15,2) NOT NULL,
  `tunjangan` decimal(15,2) NOT NULL,
  `status` enum('AKTIF','TIDAK_AKTIF','RESIGN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_karyawan_kode` (`kode`),
  KEY `ix_karyawan_nama` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karyawan`
--

LOCK TABLES `karyawan` WRITE;
/*!40000 ALTER TABLE `karyawan` DISABLE KEYS */;
INSERT INTO `karyawan` VALUES (1,'KRY26010001','ss','1154545','sss','c','00000','tes@gmail.com','1997-01-31','2026-01-31',NULL,500000.00,0.00,'TIDAK_AKTIF',NULL,'2026-01-31 12:03:49','2026-02-06 13:00:12','2026-02-06 06:00:12'),(2,'KRY26010002','oo','s','Mekanik','Cianjur','s','s@gmail.com','2020-02-01','2026-01-31',NULL,500000.00,0.00,'TIDAK_AKTIF',NULL,'2026-01-31 15:29:12','2026-02-06 13:00:07','2026-02-06 06:00:08'),(3,'KRY26020001','RINA PUTRIANA','-','ADMIN',NULL,'083817987432',NULL,NULL,'2026-02-07',NULL,500000.00,0.00,'AKTIF',NULL,'2026-02-07 10:06:56','2026-02-07 10:06:56',NULL),(4,'KRY26020002','BABAH','-','MEKANIK',NULL,'-',NULL,NULL,'2026-02-07',NULL,600000.00,0.00,'AKTIF',NULL,'2026-02-07 10:07:14','2026-02-07 10:07:14',NULL),(5,'KRY26020003','SANDI','-','MEKANIK',NULL,'-',NULL,NULL,'2026-02-10',NULL,400000.00,0.00,'AKTIF',NULL,'2026-02-10 10:18:39','2026-02-10 10:18:39',NULL),(6,'KRY26020004','MG KAKAN','-','MEKANIK',NULL,'-',NULL,NULL,'2026-02-11',NULL,500000.00,0.00,'AKTIF','-','2026-02-11 11:07:33','2026-02-11 11:07:33',NULL);
/*!40000 ALTER TABLE `karyawan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kas_bank`
--

DROP TABLE IF EXISTS `kas_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kas_bank` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `jenis` enum('CASH','BANK_BCA','BANK_MANDIRI','BANK_BRI','BANK_LAINNYA','KAS_UNIT_BENGKEL','KAS_UNIT_JASA_ANGKUT','KAS_UNIT_MOBIL','KAS_UTAMA','BANK_UTAMA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `tipe` enum('MASUK','KELUAR') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `sumber` enum('BENGKEL','JUAL_BELI_MOBIL','JASA_ANGKUT','PEMBELIAN_PART','PEMBELIAN_MOBIL','PENGELUARAN','GAJI','KASBON','PIUTANG','HUTANG','MODAL','PRIVE','LAINNYA') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `referensi_id` int DEFAULT NULL,
  `nomor_referensi` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saldo_sebelum` decimal(15,2) NOT NULL,
  `saldo_sesudah` decimal(15,2) NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci DEFAULT 'TUNAI',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_kas_bank_nomor_transaksi` (`nomor_transaksi`),
  KEY `created_by` (`created_by`),
  KEY `ix_kas_bank_jenis` (`jenis`),
  KEY `ix_kas_bank_tanggal` (`tanggal`),
  KEY `ix_kas_bank_tipe` (`tipe`),
  CONSTRAINT `kas_bank_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kas_bank`
--

LOCK TABLES `kas_bank` WRITE;
/*!40000 ALTER TABLE `kas_bank` DISABLE KEYS */;
INSERT INTO `kas_bank` VALUES (459,'KAS2603310001','2026-03-31','KAS_UNIT_BENGKEL','MASUK',50000.00,'BENGKEL',49,'PTG2603310001',0.00,50000.00,'[Bengkel] Pelunasan piutang PTG2603310001 - KWSG (TUNAI)',NULL,1,'2026-03-31 13:32:11','2026-03-31 13:32:11','TUNAI'),(460,'KAS2603310002','2026-03-31','KAS_UNIT_BENGKEL','KELUAR',10000.00,'KASBON',125,'PTG2603310002',50000.00,40000.00,'[Kasbon] Pemberian piutang kepada SANDI (TUNAI)',NULL,1,'2026-03-31 14:00:01','2026-03-31 14:00:01','TUNAI');
/*!40000 ALTER TABLE `kas_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kasbon_karyawan`
--

DROP TABLE IF EXISTS `kasbon_karyawan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kasbon_karyawan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_kasbon` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `karyawan_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `status` enum('LUNAS','BELUM_LUNAS','CICILAN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_lunas` date DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_kasbon_karyawan_nomor_kasbon` (`nomor_kasbon`),
  KEY `created_by` (`created_by`),
  KEY `ix_kasbon_karyawan_karyawan_id` (`karyawan_id`),
  KEY `ix_kasbon_karyawan_tanggal` (`tanggal`),
  CONSTRAINT `kasbon_karyawan_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `kasbon_karyawan_ibfk_2` FOREIGN KEY (`karyawan_id`) REFERENCES `karyawan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kasbon_karyawan`
--

LOCK TABLES `kasbon_karyawan` WRITE;
/*!40000 ALTER TABLE `kasbon_karyawan` DISABLE KEYS */;
INSERT INTO `kasbon_karyawan` VALUES (41,'KSB2603310001',5,'2026-03-31',10000.00,'hkjhhkh','BELUM_LUNAS',NULL,NULL,1,'2026-03-31 14:00:01','2026-03-31 14:00:01');
/*!40000 ALTER TABLE `kasbon_karyawan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobil`
--

DROP TABLE IF EXISTS `mobil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobil` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `merek` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun` int NOT NULL,
  `warna` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_plat` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_rangka` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomor_mesin` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transmisi` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bahan_bakar` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kilometer` int DEFAULT NULL,
  `harga_beli` decimal(15,2) NOT NULL,
  `harga_jual` decimal(15,2) DEFAULT NULL,
  `tipe_kepemilikan` enum('TPM','INVESTOR') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_investor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persentase_investor` decimal(5,2) NOT NULL,
  `status` enum('TERSEDIA','TERJUAL','DALAM_PERBAIKAN','BOOKING') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `tanggal_terjual` date DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `nominal_investor` decimal(15,2) NOT NULL,
  `status_bayar_beli` enum('LUNAS','BELUM_LUNAS','CICILAN') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LUNAS',
  `metode_bayar_beli` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TUNAI',
  `dp_beli` decimal(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_mobil_kode` (`kode`),
  KEY `created_by` (`created_by`),
  KEY `ix_mobil_merek` (`merek`),
  KEY `ix_mobil_nomor_plat` (`nomor_plat`),
  CONSTRAINT `mobil_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobil`
--

LOCK TABLES `mobil` WRITE;
/*!40000 ALTER TABLE `mobil` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobil_biaya_lainnya`
--

DROP TABLE IF EXISTS `mobil_biaya_lainnya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobil_biaya_lainnya` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobil_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobil_id` (`mobil_id`),
  CONSTRAINT `mobil_biaya_lainnya_ibfk_1` FOREIGN KEY (`mobil_id`) REFERENCES `mobil` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobil_biaya_lainnya`
--

LOCK TABLES `mobil_biaya_lainnya` WRITE;
/*!40000 ALTER TABLE `mobil_biaya_lainnya` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobil_biaya_lainnya` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobil_media`
--

DROP TABLE IF EXISTS `mobil_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobil_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobil_id` int NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL,
  `urutan` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobil_id` (`mobil_id`),
  CONSTRAINT `mobil_media_ibfk_1` FOREIGN KEY (`mobil_id`) REFERENCES `mobil` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobil_media`
--

LOCK TABLES `mobil_media` WRITE;
/*!40000 ALTER TABLE `mobil_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobil_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobil_part_service`
--

DROP TABLE IF EXISTS `mobil_part_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobil_part_service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobil_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `tipe` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL,
  `harga_satuan` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobil_id` (`mobil_id`),
  CONSTRAINT `mobil_part_service_ibfk_1` FOREIGN KEY (`mobil_id`) REFERENCES `mobil` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobil_part_service`
--

LOCK TABLES `mobil_part_service` WRITE;
/*!40000 ALTER TABLE `mobil_part_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobil_part_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `muatan_jasa_angkut`
--

DROP TABLE IF EXISTS `muatan_jasa_angkut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `muatan_jasa_angkut` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `supir_id` int DEFAULT NULL,
  `asal` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tujuan` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_muatan` text COLLATE utf8mb4_unicode_ci,
  `berat_muatan` decimal(10,2) DEFAULT NULL,
  `pendapatan_kotor` decimal(15,2) NOT NULL,
  `biaya_bbm` decimal(15,2) NOT NULL,
  `biaya_tol` decimal(15,2) NOT NULL,
  `biaya_makan` decimal(15,2) NOT NULL,
  `biaya_parkir` decimal(15,2) NOT NULL,
  `biaya_lainnya` decimal(15,2) NOT NULL,
  `total_biaya` decimal(15,2) NOT NULL,
  `laba_kotor` decimal(15,2) NOT NULL,
  `persentase_tpm` decimal(5,2) NOT NULL,
  `laba_tpm` decimal(15,2) NOT NULL,
  `laba_supir` decimal(15,2) NOT NULL,
  `status` enum('PROSES','SELESAI') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROSES',
  `status_bayar` enum('LUNAS','BELUM_LUNAS','CICILAN') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_bayar` date DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `supir_nama` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ritase` int NOT NULL,
  `harga_beli` decimal(15,2) NOT NULL,
  `harga_jual` decimal(15,2) NOT NULL,
  `info_kendaraan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `armada_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_muatan_jasa_angkut_nomor_transaksi` (`nomor_transaksi`),
  KEY `created_by` (`created_by`),
  KEY `supir_id` (`supir_id`),
  KEY `ix_muatan_jasa_angkut_tanggal` (`tanggal`),
  KEY `fk_muatan_armada` (`armada_id`),
  KEY `ix_muatan_jasa_angkut_status` (`status`),
  CONSTRAINT `fk_muatan_armada` FOREIGN KEY (`armada_id`) REFERENCES `armada_jasa_angkut` (`id`),
  CONSTRAINT `muatan_jasa_angkut_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `muatan_jasa_angkut_ibfk_2` FOREIGN KEY (`supir_id`) REFERENCES `supir` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `muatan_jasa_angkut`
--

LOCK TABLES `muatan_jasa_angkut` WRITE;
/*!40000 ALTER TABLE `muatan_jasa_angkut` DISABLE KEYS */;
/*!40000 ALTER TABLE `muatan_jasa_angkut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembayaran_hutang`
--

DROP TABLE IF EXISTS `pembayaran_hutang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembayaran_hutang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hutang_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TUNAI',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `ix_pembayaran_hutang_hutang_id` (`hutang_id`),
  KEY `ix_pembayaran_hutang_tanggal` (`tanggal`),
  CONSTRAINT `pembayaran_hutang_ibfk_1` FOREIGN KEY (`hutang_id`) REFERENCES `hutang_usaha` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pembayaran_hutang_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayaran_hutang`
--

LOCK TABLES `pembayaran_hutang` WRITE;
/*!40000 ALTER TABLE `pembayaran_hutang` DISABLE KEYS */;
/*!40000 ALTER TABLE `pembayaran_hutang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembayaran_piutang`
--

DROP TABLE IF EXISTS `pembayaran_piutang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembayaran_piutang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `piutang_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TUNAI',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `ix_pembayaran_piutang_piutang_id` (`piutang_id`),
  KEY `ix_pembayaran_piutang_tanggal` (`tanggal`),
  CONSTRAINT `pembayaran_piutang_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `pembayaran_piutang_ibfk_2` FOREIGN KEY (`piutang_id`) REFERENCES `piutang_usaha` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayaran_piutang`
--

LOCK TABLES `pembayaran_piutang` WRITE;
/*!40000 ALTER TABLE `pembayaran_piutang` DISABLE KEYS */;
INSERT INTO `pembayaran_piutang` VALUES (49,124,'2026-03-31',50000.00,'TUNAI',NULL,1,'2026-03-31 13:32:11','2026-03-31 13:32:11');
/*!40000 ALTER TABLE `pembayaran_piutang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembelian_spare_parts`
--

DROP TABLE IF EXISTS `pembelian_spare_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembelian_spare_parts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `supplier_id` int NOT NULL,
  `nomor_faktur` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(15,2) NOT NULL,
  `diskon` decimal(15,2) NOT NULL,
  `grand_total` decimal(15,2) NOT NULL,
  `status_bayar` enum('LUNAS','BELUM_LUNAS','CICILAN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_bayar` date DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_pembelian_spare_parts_nomor_transaksi` (`nomor_transaksi`),
  KEY `created_by` (`created_by`),
  KEY `supplier_id` (`supplier_id`),
  KEY `ix_pembelian_spare_parts_tanggal` (`tanggal`),
  CONSTRAINT `pembelian_spare_parts_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `pembelian_spare_parts_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembelian_spare_parts`
--

LOCK TABLES `pembelian_spare_parts` WRITE;
/*!40000 ALTER TABLE `pembelian_spare_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `pembelian_spare_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengeluaran_bengkel`
--

DROP TABLE IF EXISTS `pengeluaran_bengkel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pengeluaran_bengkel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'biaya_operasional',
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TUNAI',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `bisnis_kategori` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'umum',
  `muatan_id` int DEFAULT NULL,
  `armada_id` int DEFAULT NULL,
  `mobil_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_pengeluaran_bengkel_nomor_transaksi` (`nomor_transaksi`),
  KEY `created_by` (`created_by`),
  KEY `ix_pengeluaran_bengkel_tanggal` (`tanggal`),
  KEY `muatan_id` (`muatan_id`),
  KEY `mobil_id` (`mobil_id`),
  KEY `armada_id` (`armada_id`),
  CONSTRAINT `pengeluaran_bengkel_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `pengeluaran_bengkel_ibfk_2` FOREIGN KEY (`muatan_id`) REFERENCES `muatan_jasa_angkut` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pengeluaran_bengkel_ibfk_3` FOREIGN KEY (`mobil_id`) REFERENCES `mobil` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pengeluaran_bengkel_ibfk_4` FOREIGN KEY (`armada_id`) REFERENCES `armada_jasa_angkut` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengeluaran_bengkel`
--

LOCK TABLES `pengeluaran_bengkel` WRITE;
/*!40000 ALTER TABLE `pengeluaran_bengkel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pengeluaran_bengkel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piutang_usaha`
--

DROP TABLE IF EXISTS `piutang_usaha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `piutang_usaha` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_piutang` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `sumber` enum('BENGKEL','JUAL_BELI_MOBIL','JASA_ANGKUT','KASBON_KARYAWAN','LAINNYA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `referensi_id` int DEFAULT NULL,
  `nomor_referensi` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `nama_debitur` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telepon_debitur` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_debitur` text COLLATE utf8mb4_unicode_ci,
  `nominal_piutang` decimal(15,2) NOT NULL,
  `total_dibayar` decimal(15,2) NOT NULL,
  `sisa_piutang` decimal(15,2) NOT NULL,
  `tanggal_jatuh_tempo` date DEFAULT NULL,
  `tanggal_lunas` date DEFAULT NULL,
  `status` enum('BELUM_LUNAS','LUNAS','SEBAGIAN','BATAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BELUM_LUNAS',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_piutang_usaha_nomor_piutang` (`nomor_piutang`),
  KEY `created_by` (`created_by`),
  KEY `ix_piutang_usaha_customer_id` (`customer_id`),
  KEY `ix_piutang_usaha_tanggal` (`tanggal`),
  CONSTRAINT `piutang_usaha_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `piutang_usaha_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piutang_usaha`
--

LOCK TABLES `piutang_usaha` WRITE;
/*!40000 ALTER TABLE `piutang_usaha` DISABLE KEYS */;
INSERT INTO `piutang_usaha` VALUES (124,'PTG2603310001','2026-03-31','BENGKEL',112,'BGL2603310001',6,'KWSG','','',50000.00,50000.00,0.00,NULL,'2026-03-31','LUNAS','Piutang dari transaksi bengkel BGL2603310001',1,'2026-03-31 13:31:56','2026-03-31 13:32:11'),(125,'PTG2603310002','2026-03-31','KASBON_KARYAWAN',41,'KSB2603310001',NULL,'SANDI',NULL,NULL,10000.00,0.00,10000.00,NULL,NULL,'BELUM_LUNAS','hkjhhkh (Kasbon #KSB2603310001)',1,'2026-03-31 14:00:01','2026-03-31 14:00:01');
/*!40000 ALTER TABLE `piutang_usaha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slip_gaji`
--

DROP TABLE IF EXISTS `slip_gaji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slip_gaji` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_slip` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `karyawan_id` int NOT NULL,
  `periode_tahun` int NOT NULL,
  `jumlah_hadir` decimal(5,1) NOT NULL,
  `gaji_pokok` decimal(15,2) NOT NULL,
  `potongan_kasbon` decimal(15,2) NOT NULL,
  `gaji_bersih` decimal(15,2) NOT NULL,
  `status` enum('LUNAS','BELUM_LUNAS','CICILAN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_bayar` date DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `periode_minggu` int NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_slip_gaji_nomor_slip` (`nomor_slip`),
  UNIQUE KEY `uq_slip_gaji_karyawan_periode` (`karyawan_id`,`periode_minggu`,`periode_tahun`),
  KEY `created_by` (`created_by`),
  KEY `ix_slip_gaji_karyawan_id` (`karyawan_id`),
  CONSTRAINT `slip_gaji_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `slip_gaji_ibfk_2` FOREIGN KEY (`karyawan_id`) REFERENCES `karyawan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slip_gaji`
--

LOCK TABLES `slip_gaji` WRITE;
/*!40000 ALTER TABLE `slip_gaji` DISABLE KEYS */;
/*!40000 ALTER TABLE `slip_gaji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spare_parts`
--

DROP TABLE IF EXISTS `spare_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spare_parts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merek` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `satuan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stok` int NOT NULL,
  `stok_minimum` int NOT NULL,
  `harga_beli` decimal(15,2) NOT NULL,
  `harga_jual` decimal(15,2) NOT NULL,
  `lokasi_rak` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `kode_part` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_spare_parts_kode` (`kode`),
  KEY `ix_spare_parts_nama` (`nama`),
  KEY `ix_spare_parts_kode_part` (`kode_part`)
) ENGINE=InnoDB AUTO_INCREMENT=673 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spare_parts`
--

LOCK TABLES `spare_parts` WRITE;
/*!40000 ALTER TABLE `spare_parts` DISABLE KEYS */;
INSERT INTO `spare_parts` VALUES (1,'SPR26010001','Oli','Umum',NULL,'pcs',0,5,50000.00,100000.00,'','','2026-01-31 11:56:07','2026-03-31 13:31:34','2026-02-04 00:34:13',NULL,NULL),(2,'SPR26020001','OLI MEDITRAN S','OLI',NULL,'LITER',0,0,36500.00,42000.00,'-','-','2026-02-03 16:07:32','2026-03-31 13:31:34','2026-02-04 00:34:15',NULL,NULL),(3,'SPR26020002','Oli','Umum',NULL,'pcs',0,5,5000.00,10000.00,'','','2026-02-06 23:53:21','2026-03-31 13:31:34','2026-02-10 03:11:51',NULL,NULL),(4,'SPR26020003','Oli yamalube','Umum',NULL,'pcs',0,5,50000.00,10000.00,'','','2026-02-07 09:37:16','2026-03-31 13:31:34','2026-02-10 03:11:48',NULL,NULL),(5,'SPR26020004','BAUD RODA LH BLK CANTER MITSUDA','Umum',NULL,'pcs',0,0,54000.00,75000.00,'','','2026-02-07 10:00:46','2026-03-31 13:31:34','2026-02-10 03:11:56',NULL,NULL),(6,'SPR26020005','SIL RODA LUAR BLK RINO 130HT','Umum',NULL,'pcs',0,0,25000.00,50000.00,'','','2026-02-09 12:02:00','2026-03-31 13:31:34','2026-02-10 03:11:43',NULL,NULL),(7,'SPR26020006','MINYAK REM FUSO 1L','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-02-10 10:12:24','2026-03-31 13:31:34',NULL,NULL,NULL),(8,'SPR26020007','OLI GARDAN 140 JUMBO','Umum',NULL,'LITER',0,0,45000.00,55000.00,'','','2026-02-11 10:43:02','2026-03-31 13:31:34',NULL,NULL,NULL),(9,'SPR26020008','SIL RODA DEPAN CANTER 125PS','Umum',NULL,'pcs',0,0,25000.00,50000.00,'','','2026-02-12 12:59:24','2026-03-31 13:31:34',NULL,NULL,NULL),(10,'SPR26020009','GEMUK','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-02-14 09:17:47','2026-03-31 13:31:34',NULL,NULL,NULL),(11,'SPR26030001','BAUD PEN PER CANTER','Umum',NULL,'pcs',0,5,6000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(12,'SPR26030002','BAUD RODA L Canter DPN','Umum',NULL,'pcs',0,5,60500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(13,'SPR26030003','HELPER BLK PS125 MB161571','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34',NULL,NULL,NULL),(14,'SPR26030004','LAKSON 12V 105-12 AM-ALL','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34',NULL,NULL,NULL),(15,'SPR26030005','POMPA SOLAR /092130-0050X/ DENSO (B)','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34',NULL,NULL,NULL),(16,'SPR26030006','ACCU ZUUR','Umum',NULL,'pcs',0,5,6000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(17,'SPR26030007','AIR AKI','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(18,'SPR26030008','AS ARM ME011309 CANTER 125PS MMC (A)','Umum',NULL,'pcs',0,5,190000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(19,'SPR26030009','AS RODA DUTRO','Umum',NULL,'pcs',0,5,412200.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(20,'SPR26030010','BAMPER ASSY ENGKEL','Umum',NULL,'pcs',0,5,420000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(21,'SPR26030011','BAN BD KRC 15 TR75','Umum',NULL,'pcs',0,5,125000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(22,'SPR26030012','BAN LIDAH','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(23,'SPR26030013','BAN LIDAH GT 16','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(24,'SPR26030014','BAUD AS CANTER  MH001488W WTB','Umum',NULL,'pcs',0,5,5500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(25,'SPR26030015','BAUD AS CANTER HDX MH001534X','Umum',NULL,'pcs',0,5,7000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(26,'SPR26030016','BAUD AS ISUZU 5-09300-066-1 (B)','Umum',NULL,'pcs',0,5,7000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(27,'SPR26030017','BAUD AS ISUZU 6973598030','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(28,'SPR26030018','BAUD AS RINO 130HT KUNING','Umum',NULL,'pcs',0,5,8000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(29,'SPR26030019','BAUD AS RINO HITAM / 90914-10194','Umum',NULL,'pcs',0,5,8000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(30,'SPR26030020','BAUD AS RINO ORI','Umum',NULL,'pcs',0,5,24550.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(31,'SPR26030021','BAUD AS RINO SILVER 90116-10194 OEM','Umum',NULL,'pcs',0,5,13500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(32,'SPR26030022','BAUD BAMPER','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(33,'SPR26030023','BAUD CB 12 X 3,8CM','Umum',NULL,'pcs',0,5,1500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(34,'SPR26030024','BAUD CB 12 X 5CM','Umum',NULL,'pcs',0,5,800.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(35,'SPR26030025','BAUD FLANGE (14 3CM) MF140464,','Umum',NULL,'pcs',0,5,5400.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(36,'SPR26030026','BAUD FLANGE (17 2CM) MF140485,','Umum',NULL,'pcs',0,5,4590.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(37,'SPR26030027','BAUD FLANGE 10X25 (14 2,5CM) DRAT MF140460,','Umum',NULL,'pcs',0,5,2610.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(38,'SPR26030028','BAUD FLANGE 10X30 (14 3CM) MF140462,','Umum',NULL,'pcs',0,5,2880.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(39,'SPR26030029','BAUD KOPEL CANTER','Umum',NULL,'pcs',0,5,10250.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(40,'SPR26030030','BAUD KOPEL RINO 130HT','Umum',NULL,'pcs',0,5,7000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(41,'SPR26030031','BAUD KOPEL RINO 14B','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(42,'SPR26030032','BAUD MANIPUL','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(43,'SPR26030033','BAUD NEPEL BUANGAN REM RINO','Umum',NULL,'pcs',0,5,17000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(44,'SPR26030034','BAUD NEPEL BUANGAN REM RINO 14200-90870 WAKASA','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(45,'SPR26030035','BAUD NEPEL GEMUK','Umum',NULL,'pcs',0,5,4200.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(46,'SPR26030036','BAUD NEPEL GEMUK LURUS','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(47,'SPR26030037','BAUD NEPEL SOLAR 12','Umum',NULL,'pcs',0,5,2700.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(48,'SPR26030038','BAUD NEPEL SOLAR 17','Umum',NULL,'pcs',0,5,2800.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(49,'SPR26030039','BAUD NEPEL SOLAR 22','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(50,'SPR26030040','BAUD NOK AS CANTER','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(51,'SPR26030041','BAUD NOK AS POLOS RINO','Umum',NULL,'pcs',0,5,2500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(52,'SPR26030042','BAUD RODA BLK L ISUZU','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(53,'SPR26030043','BAUD RODA BLK L PS 136 HDX MITSUDA','Umum',NULL,'pcs',0,5,59000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(54,'SPR26030044','BAUD RODA BLK R ISUZU','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(55,'SPR26030045','BAUD RODA BLK R PS 136 HDX MITSUDA','Umum',NULL,'pcs',0,5,59000.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(56,'SPR26030046','BAUD RODA DPN L ISUZU','Umum',NULL,'pcs',0,5,47500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(57,'SPR26030047','BAUD RODA DPN L PS 136 HDX MITSUDA','Umum',NULL,'pcs',0,5,48500.00,0.00,NULL,NULL,'2026-03-28 03:38:54','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(58,'SPR26030048','BAUD RODA DPN R ISUZU','Umum',NULL,'pcs',0,5,47500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(59,'SPR26030049','BAUD RODA DPN R PS 136 HDX MITSUDA','Umum',NULL,'pcs',0,5,48500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(60,'SPR26030050','BAUD RODA ENGKEL KANAN','Umum',NULL,'pcs',0,5,16000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(61,'SPR26030051','BAUD RODA ENGKEL KIRI','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(62,'SPR26030052','BAUD RODA L BLK CANTER HWC','Umum',NULL,'pcs',0,5,43000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(63,'SPR26030053','BAUD RODA L BLK RINO HWC','Umum',NULL,'pcs',0,5,43000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(64,'SPR26030054','BAUD RODA L BLK RINO IBK','Umum',NULL,'pcs',0,5,62500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(65,'SPR26030055','BAUD RODA L Canter BLK ktb -MT11933RL','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(66,'SPR26030056','BAUD RODA L PS136 BLK MITSUDA','Umum',NULL,'pcs',0,5,59000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(67,'SPR26030057','BAUD RODA L Rino 130HT BLK','Umum',NULL,'pcs',0,5,54000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(68,'SPR26030058','BAUD RODA L Rino130ht DPN','Umum',NULL,'pcs',0,5,41500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(69,'SPR26030059','BAUD RODA R BLK CANTER HWC','Umum',NULL,'pcs',0,5,43000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(70,'SPR26030060','BAUD RODA R BLK CANTER IBK','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(71,'SPR26030061','BAUD RODA R BLK RINO HWC','Umum',NULL,'pcs',0,5,43000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(72,'SPR26030062','BAUD RODA R canter BLK','Umum',NULL,'pcs',0,5,62500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(73,'SPR26030063','BAUD RODA R Canter DPN','Umum',NULL,'pcs',0,5,60500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(74,'SPR26030064','BAUD RODA R Canter DPN hwc','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(75,'SPR26030065','BAUD RODA R PS136','Umum',NULL,'pcs',0,5,59000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(76,'SPR26030066','BAUD RODA R rino130ht BLK','Umum',NULL,'pcs',0,5,54000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(77,'SPR26030067','BAUD RODA R rino130ht BLK IBK','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(78,'SPR26030068','BAUD RODA R Rino130ht DPN','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(79,'SPR26030069','BAUD SASIS (17 2CM) DRAT MF140483,','Umum',NULL,'pcs',0,5,5460.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(80,'SPR26030070','BOHLAM H11 12V 55W H-400J','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(81,'SPR26030071','BOHLAM H4 12V','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(82,'SPR26030072','BOHLAM H4 12V 60/55W','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(83,'SPR26030073','BOHLAM H4 24V 75/70W','Umum',NULL,'pcs',0,5,41750.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(84,'SPR26030074','BOHLAM KAKI 1 12V','Umum',NULL,'pcs',0,5,2750.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(85,'SPR26030075','BOHLAM KAKI 1 24V','Umum','','pcs',0,5,3000.00,0.00,'','','2026-03-28 03:38:55','2026-03-31 21:54:25',NULL,'8997223733971','spare_parts/0c90a2b5-3f28-4f29-80fd-060fb4987a37.jpg'),(86,'SPR26030076','BOHLAM KAKI 2 12V /1016 STANLEE','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(87,'SPR26030077','BOHLAM KAKI 2 24V/ 2790 STANLEE','Umum',NULL,'pcs',0,5,4000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(88,'SPR26030078','BOHLAM KECIL KAKI 1 12V- STANLEE','Umum',NULL,'pcs',0,5,2500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(89,'SPR26030079','BOHLAM KECIL KAKI 1 24V- STANLEE','Umum',NULL,'pcs',0,5,2350.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(90,'SPR26030080','BOHLAM KECIL KAKI 2 12V- STANLEE','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(91,'SPR26030081','BOHLAM KECIL KAKI 2 24V- STANLEE','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(92,'SPR26030082','BOHLAM KUNING 12V KAKI 2','Umum',NULL,'pcs',0,5,7500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(93,'SPR26030083','BOHLAM SEN KUNING 12V','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(94,'SPR26030084','BOHLAM TANCAP 12V 5W /k','Umum',NULL,'pcs',0,5,1000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(95,'SPR26030085','BOHLAM TANCAP 12V 5W /sk','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(96,'SPR26030086','BOHLAM TANCAP 24V 5W /k','Umum',NULL,'pcs',0,5,1000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(97,'SPR26030087','BOHLAM TANCAP 24V 5W /sk','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(98,'SPR26030088','boring tp JP Isuzu PS 120 4h g1 /L16554LC','Umum',NULL,'pcs',0,5,600000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(99,'SPR26030089','BOSH ARM CANTER 125PS ME011254 MIT (B)','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(100,'SPR26030090','BOSH KINGPEN RINO','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(101,'SPR26030091','BOSH PER CANTER','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(102,'SPR26030092','BOSH PER ENGKEL','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(103,'SPR26030093','BOSH PER LONG CANTER -30499 MMC (B)','Umum',NULL,'pcs',0,5,13500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(104,'SPR26030094','BOSH PER RINO -73014','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(105,'SPR26030095','BOSH PER SHORT CANTER  MMC (B)','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(106,'SPR26030096','BOSH PINION CANTER 125PS MC075300','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(107,'SPR26030097','BOSH PISTON RINO 130HT 13271-69102 OEM JPN','Umum',NULL,'pcs',0,5,57500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(108,'SPR26030098','BOSHING DUMP KUNINGAN','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(109,'SPR26030099','BOSHING DUMP TEPLON','Umum',NULL,'pcs',0,5,8000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(110,'SPR26030100','BOX SIKRING BSR','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(111,'SPR26030101','BOX SIKRING KCL','Umum',NULL,'pcs',0,5,9000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(112,'SPR26030102','BRACKET DUDUKAN FILTER UDARA LUBANG 1 CANTER','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(113,'SPR26030103','BRACKET DUDUKAN FILTER UDARA LUBANG 2 CANTER ME413092','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(114,'SPR26030104','BRACKET SILINDER AS 50 BUM + BAUT ENGKEL','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(115,'SPR26030105','CAPIT TURANG BLK L300','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(116,'SPR26030106','CAPIT TURANG PANJANG KUNCI 24','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(117,'SPR26030107','CAPIT TURANG PENDEK','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(118,'SPR26030108','COVER TUTUP MANIPUL KNALPOT CANTER','Umum',NULL,'pcs',0,5,179950.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(119,'SPR26030109','COVER TUTUP TURBO CANTER','Umum',NULL,'pcs',0,5,510500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(120,'SPR26030110','DUDUKAN FILTER SOLAR/LOHAN 235TI','Umum',NULL,'pcs',0,5,175000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(121,'SPR26030111','DUDUKAN MESIN CANTER ML242056','Umum',NULL,'pcs',0,5,157500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(122,'SPR26030112','DUDUKAN MESIN/ MOUNTING RINO -78110','Umum',NULL,'pcs',0,5,80000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(123,'SPR26030113','DUDUKAN RADIATOR CANTER ME013743','Umum',NULL,'pcs',0,5,70000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(124,'SPR26030114','EMBLEM \"COLT DIESEL\"','Umum',NULL,'pcs',0,5,195300.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(125,'SPR26030115','emblem 1.000.000 E/KM004888        0001','Umum',NULL,'pcs',0,5,120000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(126,'SPR26030116','emblem 3 berlian ps 100/TBPS100','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(127,'SPR26030117','emblem colt diesel ps100/CDPS100','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(128,'SPR26030118','emblem ps 100/EBPS100','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(129,'SPR26030119','ENGSEL PINTU BAK R/L SET','Umum',NULL,'pcs',0,5,225000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(130,'SPR26030120','ENGSEL PINTU ENGKEL SET','Umum',NULL,'pcs',0,5,225000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(131,'SPR26030121','FAN BELT CANTER KTB/ set MH014025','Umum',NULL,'pcs',0,5,57500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(132,'SPR26030122','FAN BELT LAL12-03100 125PS ARPI','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(133,'SPR26030123','FAN BELT PS120 RAGASA ME900712','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(134,'SPR26030124','FAN BELT PS135 ME900207','Umum',NULL,'pcs',0,5,34000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(135,'SPR26030125','FAN BELT RINO 130HT 45367 HOP (B)','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(136,'SPR26030126','FAN BELT SZ910-45367 HINO GP','Umum',NULL,'pcs',0,5,135000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(137,'SPR26030127','FAN BELT TALI KIPAS NKR 66 ISUZU','Umum',NULL,'pcs',0,5,67500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(138,'SPR26030128','FILTER OLI 130HT TAK BIRKENS','Umum',NULL,'pcs',0,5,70000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(139,'SPR26030129','filter oli canter 125ps KTB/ME013307','Umum',NULL,'pcs',0,5,98500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(140,'SPR26030130','filter oli canter 125ps KTB/ME013307.','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(141,'SPR26030131','filter oli canter euro4 KTB/MX938500 0001','Umum',NULL,'pcs',0,5,72500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(142,'SPR26030132','FILTER OLI DUTRO EURO 4 15601-JIB40 HOP','Umum',NULL,'pcs',0,5,82500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(143,'SPR26030133','filter oli isuzu panter 2,5 gp/6944309831','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(144,'SPR26030134','FILTER OLI L300 DIESEL SKR C-10081','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(145,'SPR26030135','FILTER OLI PS 120/MARUTI C-1004 SAKURA','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(146,'SPR26030136','filter oli rino 130ht arpi/BFL1617000  9','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(147,'SPR26030137','filter oli rino 130ht hop/ 15613LAA70','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(148,'SPR26030138','FILTER OLI RINO 130HT SKR 1318','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(149,'SPR26030139','filter oli rino 14b skr/C-1104/8997879200544','Umum',NULL,'pcs',0,5,38500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(150,'SPR26030140','filter solar  bwh canter 125ps KTB /ME971553','Umum',NULL,'pcs',0,5,91000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(151,'SPR26030141','FILTER SOLAR (B)/LOHAN 235TI','Umum',NULL,'pcs',0,5,165000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(152,'SPR26030142','filter solar atas canter 125ps KTB/ME035829','Umum',NULL,'pcs',0,5,65000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(153,'SPR26030143','filter solar atas canter 125ps skr/FC1003/8997879400029','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(154,'SPR26030144','filter solar atas hino dutro 125ps arpi/CDL10-17000','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(155,'SPR26030145','filter solar atas rino 130ht hop/ 234011332L','Umum',NULL,'pcs',0,5,42500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(156,'SPR26030146','filter solar atas rino 130ht skr/FC1301/8997879400272','Umum',NULL,'pcs',0,5,28000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(157,'SPR26030147','FILTER SOLAR ATAS RINO 14B SKR 1105','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(158,'SPR26030148','FILTER SOLAR BAWAH RINO / 1109 SKR','Umum',NULL,'pcs',0,5,82500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(159,'SPR26030149','filter solar bawah rino 130ht hop/ 23390LIE50','Umum',NULL,'pcs',0,5,77500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(160,'SPR26030150','filter solar bawah rino 130ht skr/F-1008/8997879300077','Umum',NULL,'pcs',0,5,19000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(161,'SPR26030151','FILTER SOLAR DUTRO EURO 4 23304-JIE40 HOP','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(162,'SPR26030152','FILTER SOLAR DUTRO EURO 4 23304-JIE51 HOP','Umum',NULL,'pcs',0,5,82500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(163,'SPR26030153','FILTER SOLAR DUTRO EURO 4 JAF70 HOP','Umum',NULL,'pcs',0,5,43500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(164,'SPR26030154','FILTER SOLAR EURO 4 23304 JIE40 HOP','Umum',NULL,'pcs',0,5,150000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(165,'SPR26030155','filter solar isuzu panter 2,5 skr/FC15014/8997879402085','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(166,'SPR26030156','filter solar L300 skr/FC1001/8997879400005','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(167,'SPR26030157','FILTER UDARA CANTER ME017246','Umum',NULL,'pcs',0,5,189000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(168,'SPR26030158','FILTER UDARA DUTRO EURO 4 17801-JAA80','Umum',NULL,'pcs',0,5,105000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(169,'SPR26030159','FILTER UDARA RINO 130HT A-1135 SKR','Umum',NULL,'pcs',0,5,28500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(170,'SPR26030160','FILTER UDARA RINO 17801-1130L HOP','Umum',NULL,'pcs',0,5,95000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(171,'SPR26030161','FITING LAMPU KAKI 1','Umum',NULL,'pcs',0,5,3625.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(172,'SPR26030162','FITING LAMPU KAKI 2','Umum',NULL,'pcs',0,5,2500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(173,'SPR26030163','FITING LAMPU KILO METER','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(174,'SPR26030164','FITING LAMPU PLASTIK KAKI 1','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(175,'SPR26030165','FITING LAMPU PLASTIK KAKI 2','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(176,'SPR26030166','FLASHER CANTER MK387290','Umum',NULL,'pcs',0,5,47500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(177,'SPR26030167','FLASHER PS 135 MB302374','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(178,'SPR26030168','FLASHER RINO 12V-3K -32010 TYT (B)','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(179,'SPR26030169','FLASHER RINO 24V 81980-37140 TYT (B)','Umum',NULL,'pcs',0,5,55000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(180,'SPR26030170','FLEKSIBEL KNALPOT CANTER ME409059 KTB','Umum',NULL,'pcs',0,5,260000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(181,'SPR26030171','garnish pintu canter blk/ L /KTB MK403623','Umum',NULL,'pcs',0,5,57150.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(182,'SPR26030172','garnish pintu canter blk/ R/KTB MK403624','Umum',NULL,'pcs',0,5,57150.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(183,'SPR26030173','garnish pintu L dpn /canter125ps/MK403621','Umum',NULL,'pcs',0,5,11970.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(184,'SPR26030174','garnish pintu R dpn /canter125ps/MK403622','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(185,'SPR26030175','GEMUK SASIS','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(186,'SPR26030176','GIGI 3 CANTER 125PS ME608100','Umum',NULL,'pcs',0,5,575000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(187,'SPR26030177','GIGI SUSUN L300 DIESEL','Umum',NULL,'pcs',0,5,1100000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(188,'SPR26030178','HANDEL PINTU DALAM L300 DIESEL MB517028','Umum',NULL,'pcs',0,5,38314.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(189,'SPR26030179','HANDEL PINTU DALAM L300 DIESEL MB517029','Umum',NULL,'pcs',0,5,44066.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(190,'SPR26030180','hanger blk/dpn/rino 130ht','Umum',NULL,'pcs',0,5,650000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(191,'SPR26030181','HANGER/ HOLDER GANTUNGAN CANTER MK405504','Umum',NULL,'pcs',0,5,9300.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(192,'SPR26030182','INTERCOOLER STICKER KM902144','Umum',NULL,'pcs',0,5,7500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(193,'SPR26030183','JEPITAN KARPET KANAN CANTER','Umum',NULL,'pcs',0,5,130687.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(194,'SPR26030184','JOINT KOPEL PS 100','Umum',NULL,'pcs',0,5,140000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(195,'SPR26030185','JOINT KOPEL RINO','Umum',NULL,'pcs',0,5,180000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(196,'SPR26030186','KABEL PARALEL 24V','Umum',NULL,'pcs',0,5,33000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(197,'SPR26030187','KABEL PTO 3 METER','Umum',NULL,'pcs',0,5,92500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(198,'SPR26030188','KABEL PTO 3,5 METER','Umum',NULL,'pcs',0,5,90000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(199,'SPR26030189','KABEL SPEEDOMETER 83710-OWO71','Umum',NULL,'pcs',0,5,185000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(200,'SPR26030190','KACA SPION CANTER R/L 8086','Umum',NULL,'pcs',0,5,0.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(201,'SPR26030191','KACA SPION DUTRO','Umum',NULL,'pcs',0,5,34000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(202,'SPR26030192','KAMPAS KUPLING CANTER','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(203,'SPR26030193','KAMPAS KUPLING DYNA SAURUS','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(204,'SPR26030194','KAMPAS KUPLING ISUZU','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(205,'SPR26030195','KAMPAS KUPLING PS 110','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(206,'SPR26030196','KAMPAS KUPLING PS 110ET','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(207,'SPR26030197','KAMPAS KUPLING PS 120/ENGKEL TURBO','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(208,'SPR26030198','KAMPAS KUPLING PS100','Umum',NULL,'pcs',0,5,200000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(209,'SPR26030199','KAMPAS KUPLING RINO','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(210,'SPR26030200','KARET ABU CANTER 125 /MB112207','Umum',NULL,'pcs',0,5,2250.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(211,'SPR26030201','KARET ABU CANTER HDX BSR MK58599','Umum',NULL,'pcs',0,5,3500.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(212,'SPR26030202','KARET ABU CANTER HDX KCL MK 585611','Umum',NULL,'pcs',0,5,3750.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(213,'SPR26030203','KARET ABU CANTER NB 160920','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(214,'SPR26030204','KARET ABU ENGKEL CANTER MT160923 IRS','Umum',NULL,'pcs',0,5,2250.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(215,'SPR26030205','KARET ABU ENGKEL RINO ADR-30294','Umum',NULL,'pcs',0,5,2250.00,0.00,NULL,NULL,'2026-03-28 03:38:55','2026-03-31 13:31:34',NULL,NULL,NULL),(216,'SPR26030206','KARET ABU RINO 14B IRS -36041','Umum',NULL,'pcs',0,5,2250.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(217,'SPR26030207','KARET ABU RINO 14B LEBAR','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(218,'SPR26030208','KARET ABU RINO ET 04905-37080 IRS','Umum',NULL,'pcs',0,5,2250.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(219,'SPR26030209','KARET ABU RINO ET ktb -573IDN','Umum',NULL,'pcs',0,5,3500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(220,'SPR26030210','KARET ABU RINO130ht/Dutro/fuso/MC808354','Umum',NULL,'pcs',0,5,2500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(221,'SPR26030211','KARET BRAKE CANTER 125PS ACIPI 14-11','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(222,'SPR26030212','KARET BRAKE KIT ME290913 OHK CANTER','Umum',NULL,'pcs',0,5,110000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(223,'SPR26030213','KARET BRAKE KIT+STANG 14-01 ACIPI','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(224,'SPR26030214','KARET BRAKE KIT+STANG -25035 OHK','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(225,'SPR26030215','Karet Central ps100','Umum',NULL,'pcs',0,5,65000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(226,'SPR26030216','Karet Central Rem Canter TMC-448857 sk jpn','Umum',NULL,'pcs',0,5,62500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(227,'SPR26030217','Karet Central Rem Rino 04493-36230 hop (b)','Umum',NULL,'pcs',0,5,90000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(228,'SPR26030218','KARET GANTUNGAN KNALPOT RINO 17565-OW010','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(229,'SPR26030219','KARET HANGER JUMBO UNIVERSAL','Umum',NULL,'pcs',0,5,9000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(230,'SPR26030220','KARET KACA BLK CANTER MK402584','Umum',NULL,'pcs',0,5,109800.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(231,'SPR26030221','karet kopel canter 125ps','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(232,'SPR26030222','KARET MOUNTING PERSENELENG CANTER 125PS MC122542','Umum',NULL,'pcs',0,5,51500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(233,'SPR26030223','KARET MOUNTING PERSENELENG PS 100 MARUTI MB201952','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(234,'SPR26030224','KARET RADIATOR CANTER MC127153','Umum',NULL,'pcs',0,5,52500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(235,'SPR26030225','KARET REM AVANZA/FTR 04521','Umum',NULL,'pcs',0,5,9000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(236,'SPR26030226','KARET REM BLK ENGKEL PS 100','Umum',NULL,'pcs',0,5,9000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(237,'SPR26030227','karet rem canter 125ps ktb MB060573IDN     0001','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(238,'SPR26030228','KARET REM CANTER 125ps sk jp 01030253','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(239,'SPR26030229','karet rem canter HDX sk jp 01030763/34571187469272','Umum',NULL,'pcs',0,5,8000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(240,'SPR26030230','KARET REM DPN ENGKEL PS 100','Umum',NULL,'pcs',0,5,11000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(241,'SPR26030231','KARET REM ENGKEL RINO 1 1/8 SC 80353 SK JPN','Umum',NULL,'pcs',0,5,9500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(242,'SPR26030232','KARET REM ENGKEL TIPIS 11/8 -263','Umum',NULL,'pcs',0,5,8250.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(243,'SPR26030233','KARET REM MANGKOK 11/4 14B DPN ENGKEL RINO -593R','Umum',NULL,'pcs',0,5,8250.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(244,'SPR26030234','KARET REM MANGKOK 11/8 H rino 14B/engkel canter SC1500R','Umum',NULL,'pcs',0,5,7000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(245,'SPR26030235','KARET REM MANGKOK BLK ENGKEL 1 1/8 PS100 sk jp sc30023','Umum',NULL,'pcs',0,5,6500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(246,'SPR26030236','KARET REM MANGKOK RINO 14B 7/8 -47546','Umum',NULL,'pcs',0,5,8500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(247,'SPR26030237','karet rem puso 190PS sk jp','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(248,'SPR26030238','KARET REM RINO 1 3/16 130ht sk jp SC40493R','Umum',NULL,'pcs',0,5,9750.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(249,'SPR26030239','KARET SHOCKBREKER BLK','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(250,'SPR26030240','KARET SHOCKBREKER DPN','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(251,'SPR26030241','KARET WIPER 17\" BOSCH','Umum',NULL,'pcs',0,5,38500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(252,'SPR26030242','KARET WIPER 18\'\' BOSCH','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(253,'SPR26030243','KARET WIPER 19\" KANEBO','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(254,'SPR26030244','KARET/ STOPPER HELPER CANTER MC114546','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(255,'SPR26030245','KARET/ STOPPER HELPER CANTER MK114546 FUJINATA','Umum',NULL,'pcs',0,5,16000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(256,'SPR26030246','KARET/ STOPPER UNIVERSAL + BAUD','Umum',NULL,'pcs',0,5,3250.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(257,'SPR26030247','KARET/STOPPER HELPER RINO -36020','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(258,'SPR26030248','KING PEN CANTER MC995305 (B)','Umum',NULL,'pcs',0,5,117500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(259,'SPR26030249','KING PEN RINO KT-15.X NASIONAL','Umum',NULL,'pcs',0,5,235000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(260,'SPR26030250','KING PEN SET CANTER KF-16.X NATIONAL (A)','Umum',NULL,'pcs',0,5,210000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(261,'SPR26030251','kit kupling atas 14B sk jp 17912','Umum',NULL,'pcs',0,5,52500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(262,'SPR26030252','kit kupling atas canter sk jp/32672','Umum',NULL,'pcs',0,5,102500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(263,'SPR26030253','KIT KUPLING ATAS PS100 SK31151-2 JPN','Umum',NULL,'pcs',0,5,70000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(264,'SPR26030254','kit kupling atas Rino 130ht utm/0431125020','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(265,'SPR26030255','KIT KUPLING ATS CANTER UTM ME509766.','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(266,'SPR26030256','KIT KUPLING ATS RINO 130ht sk jp/46691','Umum',NULL,'pcs',0,5,47500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(267,'SPR26030257','kit kupling bawah canter sk jp/32701','Umum',NULL,'pcs',0,5,135000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(268,'SPR26030258','kit kupling bawah canter utm/ME615132','Umum',NULL,'pcs',0,5,47500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(269,'SPR26030259','KIT KUPLING BAWAH PS100 SK31161-2 JPN','Umum',NULL,'pcs',0,5,52500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(270,'SPR26030260','kit kupling bawah Rino 130ht sk jp/4571187443240','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(271,'SPR26030261','KIT KUPLING BWH CANTER UTM ME615132','Umum',NULL,'pcs',0,5,48500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(272,'SPR26030262','KIT KUPLING RINO BWH 40281-3','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(273,'SPR26030263','KIT POWER STEERING DUTRO 130HT 44110-37222 LAISIN','Umum',NULL,'pcs',0,5,200000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(274,'SPR26030264','KIT REM TANGAN CANTER FE74T MIT (B)','Umum',NULL,'pcs',0,5,57500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(275,'SPR26030265','KIT REM TANGAN RINO TYT B','Umum',NULL,'pcs',0,5,95000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(276,'SPR26030266','KLEMAN AKI TIMAH','Umum',NULL,'pcs',0,5,17000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(277,'SPR26030267','KLEMAN AKI TIMAH JUMBO N70','Umum',NULL,'pcs',0,5,23500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(278,'SPR26030268','KLEMAN SELANG  7/8 inch','Umum',NULL,'pcs',0,5,1500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(279,'SPR26030269','KLEMAN SELANG 1 1/4\'\'','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(280,'SPR26030270','KLEMAN SELANG 1/2','Umum',NULL,'pcs',0,5,1300.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(281,'SPR26030271','KLEMAN SELANG 2 inch','Umum',NULL,'pcs',0,5,4000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(282,'SPR26030272','KLEMAN SELANG 27-51','Umum',NULL,'pcs',0,5,3500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(283,'SPR26030273','KLEMAN SELANG 3 1/2 inch','Umum',NULL,'pcs',0,5,6000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(284,'SPR26030274','KLEMAN SELANG 3/4','Umum',NULL,'pcs',0,5,1500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(285,'SPR26030275','KLEMAN SELANG 4\"','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(286,'SPR26030276','KLEMAN SELANG 5/8 TWN','Umum',NULL,'pcs',0,5,1250.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(287,'SPR26030277','KLEMAN SELANG 5/8\'\' WT','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(288,'SPR26030278','KLIP BEKLEDING','Umum',NULL,'pcs',0,5,1500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(289,'SPR26030279','KLIP GARNISH PINTU','Umum',NULL,'pcs',0,5,27800.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(290,'SPR26030280','KLIP TUTUP FILTER UDARA CANTER','Umum',NULL,'pcs',0,5,4500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(291,'SPR26030281','KOPEL PTO UNIVERSAL','Umum',NULL,'pcs',0,5,350000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(292,'SPR26030282','KRUK AS PS 100 0,25','Umum',NULL,'pcs',0,5,2100000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(293,'SPR26030283','KUL DINAMO JALAN PS 135','Umum',NULL,'pcs',0,5,5500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(294,'SPR26030284','KUL DINAMO JALAN PS100','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(295,'SPR26030285','KUL DINAMO JALAN RINO 0438015 GP','Umum',NULL,'pcs',0,5,7500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(296,'SPR26030286','KUL DINAMO JALAN RINO SAURUS 125HT 2731-89103','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(297,'SPR26030287','KUL STATER CANTER JMTSX-36 FCC JPN','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(298,'SPR26030288','KUL STATER RINO 0438015','Umum',NULL,'pcs',0,5,7500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(299,'SPR26030289','KUL STATER RINO 28510-0500','Umum',NULL,'pcs',0,5,65000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(300,'SPR26030290','KUL STATER RINO VRB-930','Umum',NULL,'pcs',0,5,65000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(301,'SPR26030291','KUPING BAMPER CANTER R','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(302,'SPR26030292','KUPING BAMPER L KM002956M','Umum',NULL,'pcs',0,5,48500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(303,'SPR26030293','KUPING BAMPER R KM002957M','Umum',NULL,'pcs',0,5,48150.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(304,'SPR26030294','LAHER ALTERNATOR PS110/125/136 NSK B17-116T1','Umum',NULL,'pcs',0,5,100500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(305,'SPR26030295','LAHER DINAMO KOYO 62032RSCM','Umum',NULL,'pcs',0,5,37000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(306,'SPR26030296','LAHER ENGKEL 32210','Umum',NULL,'pcs',0,5,120000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(307,'SPR26030297','LAHER ENGKEL DPN DLM 32208','Umum',NULL,'pcs',0,5,120000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(308,'SPR26030298','laher gigi susun dp 130HT J38-3NR.C3 -538','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(309,'SPR26030299','LAHER KINGPEN RINO NSK 38TAG12','Umum',NULL,'pcs',0,5,52500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(310,'SPR26030300','LAHER PINION 30311 KOYO JPN','Umum',NULL,'pcs',0,5,300000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(311,'SPR26030301','LAHER PINION 30311 NSK JPN','Umum',NULL,'pcs',0,5,315000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(312,'SPR26030302','LAHER PINION GARDAN SAMPING 32214','Umum',NULL,'pcs',0,5,270000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(313,'SPR26030303','LAHER PINION PS 120 30309DJR NSK JPN','Umum',NULL,'pcs',0,5,205000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(314,'SPR26030304','LAHER PINION PS 120 30309DJR NTN JPN','Umum',NULL,'pcs',0,5,200000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(315,'SPR26030305','LAHER PS100 DOBEL 30210 NTN','Umum',NULL,'pcs',0,5,122000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(316,'SPR26030306','laher roda blakang dlm canter125ps/30212.','Umum',NULL,'pcs',0,5,175000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(317,'SPR26030307','laher roda blakang dlm canter125ps/30212/4549250121227','Umum',NULL,'pcs',0,5,180000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(318,'SPR26030308','LAHER RODA SAMPING 30214JR KOYO','Umum',NULL,'pcs',0,5,260000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(319,'SPR26030309','LAHER RODA BLK DLM RINO 115 39585/20','Umum',NULL,'pcs',0,5,300000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(320,'SPR26030310','LAHER RODA BLK LUAR KOYOjp/32211/4549250292583','Umum',NULL,'pcs',0,5,170000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(321,'SPR26030311','laher roda blkng DLM rino130ht koyoJP/32213/4549250021824','Umum',NULL,'pcs',0,5,265000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(322,'SPR26030312','laher roda blkng luar canter125ps/30211/4549250292576','Umum',NULL,'pcs',0,5,160000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(323,'SPR26030313','laher roda depan DLM RINO130ht/33210/4549250012709','Umum',NULL,'pcs',0,5,170000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(324,'SPR26030314','laher roda dpn canter Rino KOYOjp/32207/4549250017810','Umum',NULL,'pcs',0,5,92500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(325,'SPR26030315','LAHER RODA DPN ENGKEL LUAR 32206','Umum',NULL,'pcs',0,5,80000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(326,'SPR26030316','laher roda dpn luar ps100 NSK/30207/LHNSK30207','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(327,'SPR26030317','laher stelan PS 100 28985/21','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(328,'SPR26030318','LAHER TRANS. DUTRO','Umum',NULL,'pcs',0,5,350000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(329,'SPR26030319','laher ujung pinion canter 125PS M30-BCG32','Umum',NULL,'pcs',0,5,260000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(330,'SPR26030320','LAKSON 24V AM-ALL','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(331,'SPR26030321','LEM AUTO SEALER BSR','Umum',NULL,'pcs',0,5,26500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(332,'SPR26030322','LEM AUTO SEALER KCL','Umum',NULL,'pcs',0,5,14850.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(333,'SPR26030323','LEM SILIKON HITAM ASTRA ISUZU REINZOSIL','Umum',NULL,'pcs',0,5,23000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(334,'SPR26030324','LEM THREEBOND SI00007','Umum',NULL,'pcs',0,5,23500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(335,'SPR26030325','LIS LAMPU CANTER R/L','Umum',NULL,'pcs',0,5,34300.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(336,'SPR26030326','LOCK PEN RINO 130HT','Umum',NULL,'pcs',0,5,11000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(337,'SPR26030327','MASTER KUPLING ATS CANTER ME507832 SANYCO','Umum',NULL,'pcs',0,5,197500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(338,'SPR26030328','MASTER KUPLING ATS RINO -25040 SANYCO','Umum',NULL,'pcs',0,5,170000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(339,'SPR26030329','MASTER KUPLING BWH CANTER ME602994','Umum',NULL,'pcs',0,5,117500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(340,'SPR26030330','MASTER KUPLING BWH RINO 31470-37080','Umum',NULL,'pcs',0,5,107500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(341,'SPR26030331','MASTER REM BLK KANAN PS 100 DOBEL MB060582','Umum',NULL,'pcs',0,5,204000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(342,'SPR26030332','MASTER REM BLK KIRI PS 100 DOBEL MB060583','Umum',NULL,'pcs',0,5,204000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(343,'SPR26030333','MASTER REM DPN KANAN RINO 47520-37080','Umum',NULL,'pcs',0,5,228000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(344,'SPR26030334','MASTER REM DPN KIRI RINO 47520-37100','Umum',NULL,'pcs',0,5,228000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(345,'SPR26030335','METAL BULAN 0,15 CANTER ME013561SET','Umum',NULL,'pcs',0,5,234900.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(346,'SPR26030336','METAL BULAN STD CANTER ME013560SET','Umum',NULL,'pcs',0,5,247500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(347,'SPR26030337','metal duduk 0.25 rino /130/110 daido jp','Umum',NULL,'pcs',0,5,190000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(348,'SPR26030338','METAL DUDUK CANTER STD ME999384','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(349,'SPR26030339','METAL DUDUK PS125 0.25 ME999385','Umum',NULL,'pcs',0,5,375000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(350,'SPR26030340','METAL JALAN 0,25 R4650A DAIDO JPN/ PANTHER 2,5','Umum',NULL,'pcs',0,5,172500.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(351,'SPR26030341','METAL JALAN 0,50 NKR71 ISUZU R4547K','Umum',NULL,'pcs',0,5,300000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(352,'SPR26030342','metal jalan 0.25 rino 130/110 daido jp','Umum',NULL,'pcs',0,5,147000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(353,'SPR26030343','METAL JALAN CANTER 0.25 ME995154','Umum',NULL,'pcs',0,5,200000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(354,'SPR26030344','METAL JALAN CANTER STD ME995153','Umum',NULL,'pcs',0,5,150000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(355,'SPR26030345','Metal Jalan PS100/120 R6029K','Umum',NULL,'pcs',0,5,140000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(356,'SPR26030346','METAL JALAN STD ME995148 CANTER PS 120','Umum',NULL,'pcs',0,5,306000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(357,'SPR26030347','MIKA FOGLAMP L/R CANTER 1 SET','Umum',NULL,'pcs',0,5,73200.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(358,'SPR26030348','MIKA KACA LAMPU KIRI CANTER','Umum',NULL,'pcs',0,5,150000.00,0.00,NULL,NULL,'2026-03-28 03:38:56','2026-03-31 13:31:34',NULL,NULL,NULL),(359,'SPR26030349','MIKA LAMPU BLK CANTER','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(360,'SPR26030350','MIKA LAMPU DPN L CANTER','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(361,'SPR26030351','MIKA LAMPU DPN R CANTER','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(362,'SPR26030352','MIKA SEN CANTER','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(363,'SPR26030353','MINYAK REM 1L KTB','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(364,'SPR26030354','MINYAK REM KCL','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(365,'SPR26030355','MOUNTING PERSENELENG RINO 130HT -78010 FUJINATA','Umum',NULL,'pcs',0,5,52500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(366,'SPR26030356','MUR AS RODA REPAIR KIT 48182-80141 SGW','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(367,'SPR26030357','MUR AS RODA REPAIR KIT BM 105 -28001 RINO','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(368,'SPR26030358','MUR AS RODA REPAIR KIT CANTER MIT (B)','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(369,'SPR26030359','MUR AS RODA REPAIR KIT RINO 14B 90170-26001 TYT (B)','Umum',NULL,'pcs',0,5,37500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(370,'SPR26030360','MUR PLASTIK KUNING NT3','Umum',NULL,'pcs',0,5,1200.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(371,'SPR26030361','MUR PLASTIK PUTIH','Umum',NULL,'pcs',0,5,1000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(372,'SPR26030362','MUR REBUNG CANTER KANAN MT420221','Umum',NULL,'pcs',0,5,16000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(373,'SPR26030363','MUR REBUNG CANTER KIRI MT420221','Umum',NULL,'pcs',0,5,16500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(374,'SPR26030364','MUR REBUNG RINO KANAN 42427-37050','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(375,'SPR26030365','MUR REBUNG RINO KIRI 42427-37020','Umum',NULL,'pcs',0,5,34000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(376,'SPR26030366','MUR REPAIR KIT BM 105 -28001','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(377,'SPR26030367','MUR SRUMBUNG isuzu NKR 66 5-37211-007','Umum',NULL,'pcs',0,5,138500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(378,'SPR26030368','OLI GARDAN GYRO','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(379,'SPR26030369','OLI GARDAN RORED 1L','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(380,'SPR26030370','OLI GARDAN WIN 140','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(381,'SPR26030371','OLI HIDROLIK 1L','Umum',NULL,'pcs',0,5,22000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(382,'SPR26030372','OLI MEDITRAN S 10L','Umum',NULL,'pcs',0,5,361300.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(383,'SPR26030373','OLI MESIN RIMULA R2 40-CF','Umum',NULL,'pcs',0,5,40740.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(384,'SPR26030374','OLI PERSENELENG 90 GYRO','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(385,'SPR26030375','OLI PERSENELENG SPIRAX 90 GL','Umum',NULL,'pcs',0,5,52450.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(386,'SPR26030376','OLI PERSENELING 90 WIN','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(387,'SPR26030377','OLI POWER STERING 1L WIN ATF','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(388,'SPR26030378','OLI SILIKON','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(389,'SPR26030379','OLI TREATMENT STP 250ML','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(390,'SPR26030380','OLI TREATMENT STP 300ML','Umum',NULL,'pcs',0,5,95000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(391,'SPR26030381','ORING NOZEL/LOHAN 235TI','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(392,'SPR26030382','PAKING DEKSEL CANTER ME227518 COAK 2','Umum',NULL,'pcs',0,5,345600.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(393,'SPR26030383','PAKING DEKSEL CANTER ME227519 COAK 3','Umum',NULL,'pcs',0,5,332000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(394,'SPR26030384','PAKING DEKSEL L300','Umum',NULL,'pcs',0,5,160000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(395,'SPR26030385','PAKING DEKSEL MARUSAN.','Umum',NULL,'pcs',0,5,425000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(396,'SPR26030386','PAKING DEKSEL RINO MARUSAN','Umum',NULL,'pcs',0,5,535000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(397,'SPR26030387','PAKING KNALPOT CANTER SEGITIGA','Umum',NULL,'pcs',0,5,11500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(398,'SPR26030388','PAKING KNALPOT PS 125 BULAT','Umum',NULL,'pcs',0,5,5500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(399,'SPR26030389','PAKING KNALPOT PS120','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(400,'SPR26030390','PAKING KNALPOT RINO SEGITIGA','Umum',NULL,'pcs',0,5,11500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(401,'SPR26030391','PAKING MANIPUL  EX CANTER','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(402,'SPR26030392','PAKING MANIPUL EX RINO 130HT','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(403,'SPR26030393','PAKING MANIPUL NMR 71','Umum',NULL,'pcs',0,5,90000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(404,'SPR26030394','PAKING TURBO CANTER ME013727','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(405,'SPR26030395','PAKING TURBO RINO TYT (B)','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(406,'SPR26030396','PAKING TUTUP KLEP 14B 11213-58030 TOYOTA','Umum',NULL,'pcs',0,5,94000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(407,'SPR26030397','PAKING TUTUP KLEP CANTER ME011279','Umum',NULL,'pcs',0,5,28000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(408,'SPR26030398','PAKING TUTUP KLEP RINO','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(409,'SPR26030399','PAKING TUTUP KLEP RINO 130HT 11213-E0060 HOP (B)','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(410,'SPR26030400','PAKING TUTUP KLEP RINO TYT','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(411,'SPR26030401','PAKU PLASTIK','Umum',NULL,'pcs',0,5,900.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(412,'SPR26030402','PAKU SASIS CANTER 10mm X 3cm MF468252','Umum',NULL,'pcs',0,5,2160.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(413,'SPR26030403','PAKU SASIS CANTER 11mm X 3cm','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(414,'SPR26030404','PAKU SASIS CANTER 9,5X3,8cm','Umum',NULL,'pcs',0,5,2210.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(415,'SPR26030405','PAKU SASIS CANTER 9X4cm','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(416,'SPR26030406','PALANGAN SASIS CANTER BLK','Umum',NULL,'pcs',0,5,489000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(417,'SPR26030407','PALANGAN SASIS SET BLK CANTER MC128369','Umum',NULL,'pcs',0,5,423500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(418,'SPR26030408','PALANGAN SASIS SET TENGAH CANTER MK551542','Umum',NULL,'pcs',0,5,607500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(419,'SPR26030409','PALANGAN SASIS TENGAH CANTER','Umum',NULL,'pcs',0,5,360000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(420,'SPR26030410','PALANGAN SHOCKBREKER ASSY CANTER MB387263','Umum',NULL,'pcs',0,5,598500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(421,'SPR26030411','PANEL TUTUP SEGITIGA CANTER MK405110','Umum',NULL,'pcs',0,5,19600.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(422,'SPR26030412','PEDAL GAS 12-10 ACIPI','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(423,'SPR26030413','PEN PER BLK CANTER','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(424,'SPR26030414','PEN PER DPN CANTER','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(425,'SPR26030415','PEN PER RINO TYT (B)','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(426,'SPR26030416','PEN PISTON RINO 130HT HOP (B) 13251-EO120X','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(427,'SPR26030417','PENIK STATER SWITCH ps 100 ss-1522','Umum',NULL,'pcs',0,5,180000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(428,'SPR26030418','PER GAS FE74 MIT (B)','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(429,'SPR26030419','PER PIRODO CANTER FE74 MIT(B)','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(430,'SPR26030420','PER PIRODO RINO','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(431,'SPR26030421','PER SINKRONIS CANTER ME-610061','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(432,'SPR26030422','PIN KIT PIRODO CANTER 125PS','Umum',NULL,'pcs',0,5,7000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(433,'SPR26030423','PIN KIT PIRODO DYNA 47447-60010B JAC','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(434,'SPR26030424','PIN KIT PIRODO RINO 130HT','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(435,'SPR26030425','PIN METAL BULAN','Umum',NULL,'pcs',0,5,4000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(436,'SPR26030426','PIPA KNALPOT RINO 125HT FIK 2008','Umum',NULL,'pcs',0,5,375000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(437,'SPR26030427','PIRODO 04495-LHA32 HOP/ pcs','Umum',NULL,'pcs',0,5,475000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(438,'SPR26030428','PIRODO BLK NTB RINO','Umum',NULL,'pcs',0,5,200000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(439,'SPR26030429','PIRODO DPN 125HT RCA','Umum',NULL,'pcs',0,5,160000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(440,'SPR26030430','PIRODO DPN/BLK CANTER NTB FE74T','Umum',NULL,'pcs',0,5,170000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(441,'SPR26030431','PIRODO HAND BRAKE DUTRO X-POWER KGW-229','Umum',NULL,'pcs',0,5,130000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(442,'SPR26030432','PIRODO HAND BRAKE SHOE K-168 KGW RINO ENGKEL','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(443,'SPR26030433','PIRODO HAND BRAKE SHOE K-682 KGW CANTER','Umum',NULL,'pcs',0,5,92500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(444,'SPR26030434','PIRODO NTB DPN Rino130ht','Umum',NULL,'pcs',0,5,180000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(445,'SPR26030435','PIRODO X-POWER BLK DUTRO 47442-LAA20 BIRKENS','Umum',NULL,'pcs',0,5,260000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(446,'SPR26030436','PIRODO X-POWER BLK DUTRO 47442-LAA20 HOP','Umum',NULL,'pcs',0,5,270000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(447,'SPR26030437','PIRODO X-POWER DPN DUTRO 47441-LAA20 HOP','Umum',NULL,'pcs',0,5,245000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(448,'SPR26030438','PISTON TUNER/LOHAN 235TI','Umum',NULL,'pcs',0,5,175000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(449,'SPR26030439','PLAT DEK STIR L300 DIESEL','Umum',NULL,'pcs',0,5,590000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(450,'SPR26030440','pompa solar /092130-0050/PO00122 ND (B)','Umum',NULL,'pcs',0,5,37500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(451,'SPR26030441','rilay biru 12v 90987-02027','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(452,'SPR26030442','RILEY 12V 4RD 933 332 32 HELLA','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(453,'SPR26030443','RILEY KAKI 4 12V BOSCH','Umum',NULL,'pcs',0,5,28000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(454,'SPR26030444','RILEY KAKI 4 24V ISUZU NMR 8972649470 TAIWAN','Umum',NULL,'pcs',0,5,170000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(455,'SPR26030445','RILEY KAKI 5 24V BOSCH','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(456,'SPR26030446','RILEY KECIL 12V KAKI 4 DENSO','Umum',NULL,'pcs',0,5,28000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(457,'SPR26030447','RILEY KECIL 24V KAKI 5 OMRON','Umum',NULL,'pcs',0,5,29000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(458,'SPR26030448','RILEY LAMPU 24V 90987-02005','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(459,'SPR26030449','RILEY LAMPU 24V 90987-02007 KAKI 4','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(460,'SPR26030450','RILEY LAMPU 90987-02005 24V','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(461,'SPR26030451','RILEY STATER ABU 12V RINO 130HT T2002','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(462,'SPR26030452','riley lampu/90987T2001','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(463,'SPR26030453','RING GIGI BOLU KCL RINO 130HT','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(464,'SPR26030454','RING KINGPEN MB025386','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(465,'SPR26030455','RING NOZZLE ME016564W','Umum',NULL,'pcs',0,5,12000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(466,'SPR26030456','RING NOZZLE PS 120 ME 016539','Umum',NULL,'pcs',0,5,12000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(467,'SPR26030457','ring rebung canter MW028255','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(468,'SPR26030458','ring rebung rino','Umum',NULL,'pcs',0,5,6500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(469,'SPR26030459','ring rebung rino 42428-36020 TYT','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(470,'SPR26030460','RING SEHER 0,50 PS 120 RAGASA ME997241J','Umum',NULL,'pcs',0,5,1989000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(471,'SPR26030461','RING SEHER 0.5 CANTER TRB HDX ME996567','Umum',NULL,'pcs',0,5,1083000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(472,'SPR26030462','RING SEHER/PCS STD CANTER ME996566','Umum',NULL,'pcs',0,5,291000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(473,'SPR26030463','RING SEHER STD RINO 130HT S1304-E0281 HINO GP','Umum',NULL,'pcs',0,5,1025000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(474,'SPR26030464','RING SOLAR','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(475,'SPR26030465','RING SOLAR 19','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(476,'SPR26030466','RING TEMBAGA','Umum',NULL,'pcs',0,5,3000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(477,'SPR26030467','RING TEMBAGA (ORI)','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(478,'SPR26030468','SAKLAR SAIN 12V -25110 SH','Umum',NULL,'pcs',0,5,180000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(479,'SPR26030469','SEHER 0,5 CANTER IZUMI ME220470','Umum',NULL,'pcs',0,5,1450000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(480,'SPR26030470','SEHER STD CANTER IZUMI ME220470','Umum',NULL,'pcs',0,5,1750000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(481,'SPR26030471','SELANG BLOWER PS120 RAGASA','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(482,'SPR26030472','SELANG OUT CILINDER','Umum',NULL,'pcs',0,5,150000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(483,'SPR26030473','SELANG PIPA OUTPUT KP75A','Umum',NULL,'pcs',0,5,95000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(484,'SPR26030474','SELANG PLEKSIBEL POWER STEERING CANTER','Umum',NULL,'pcs',0,5,200000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(485,'SPR26030475','SELANG POMPA P/S CANTER','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(486,'SPR26030476','SELANG RADIATOR ATS ISUZU GIGA NMR81','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(487,'SPR26030477','SELANG RADIATOR ATS RINO 16571-OW100','Umum',NULL,'pcs',0,5,95000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(488,'SPR26030478','SELANG RADIATOR BWH ISUZU GIGA NMR81','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(489,'SPR26030479','SELANG SOLAR 6mm /meter','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(490,'SPR26030480','SELANG SOLAR 8mm/ meter','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(491,'SPR26030481','SELANG TURBO no.3 17343-JIB20 HOP','Umum',NULL,'pcs',0,5,127500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(492,'SPR26030482','SELANG TURBO no.4/2 17344-JIB70','Umum',NULL,'pcs',0,5,130000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(493,'SPR26030483','SELANG VENTILATOR RINO 130HT ORI 12261-78400','Umum',NULL,'pcs',0,5,108000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(494,'SPR26030484','SEPATU SASIS BLK CANTER','Umum',NULL,'pcs',0,5,425000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(495,'SPR26030485','SET SHOCKBREKER PS E 2004Z blk','Umum',NULL,'pcs',0,5,404000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(496,'SPR26030486','SET STOP LAMP ASSY RINO 130HT','Umum',NULL,'pcs',0,5,120000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(497,'SPR26030487','SIKRING BOTOL/ BULAT','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(498,'SPR26030488','SIKRING BSR','Umum',NULL,'pcs',0,5,700.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(499,'SPR26030489','SIKRING KECIL','Umum',NULL,'pcs',0,5,450.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(500,'SPR26030490','SIL AS KOPLING RINO JPN','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(501,'SPR26030491','SIL AS KUPLING PER. DPN CANTER 125HT ME623281 JPN','Umum',NULL,'pcs',0,5,22500.00,0.00,NULL,NULL,'2026-03-28 03:38:57','2026-03-31 13:31:34',NULL,NULL,NULL),(502,'SPR26030492','SIL AS KUPLING/ DPN RINO 125HT 90311-35023 JPN','Umum',NULL,'pcs',0,5,32500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(503,'SPR26030493','SIL BOOSTER DUTRO/RINO TYT (B)','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(504,'SPR26030494','SIL BUM 125x140x11','Umum',NULL,'pcs',0,5,70000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(505,'SPR26030495','sil bum 136','Umum',NULL,'pcs',0,5,75000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(506,'SPR26030496','sil bum 140','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(507,'SPR26030497','sil bum 145','Umum',NULL,'pcs',0,5,90000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(508,'SPR26030498','sil bum 150','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(509,'SPR26030499','sil bum 45x55','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(510,'SPR26030500','sil bum 60x68','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(511,'SPR26030501','sil bum 70x80','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(512,'SPR26030502','sil bum abu 45x53','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(513,'SPR26030503','sil bum abu 60x68','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(514,'SPR26030504','sil bum abu 70x80','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(515,'SPR26030505','SIL GAS','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(516,'SPR26030506','SIL GAS DENSO','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(517,'SPR26030507','SIL KINGPEN MB294059','Umum',NULL,'pcs',0,5,92500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(518,'SPR26030508','SIL KLEP PENDEK RINO','Umum',NULL,'pcs',0,5,12000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(519,'SPR26030509','SIL KLEP PJG CANTER','Umum',NULL,'pcs',0,5,12000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(520,'SPR26030510','SIL KRUK AS/ GENENG CANTER 125PS CORTECO','Umum',NULL,'pcs',0,5,175000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(521,'SPR26030511','SIL KRUK AS/ GENENG CANTER 125PS MH011754 JPN','Umum',NULL,'pcs',0,5,140000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(522,'SPR26030512','SIL KRUK AS/ GENENG RINO 130HT 90311-99002 HOP (A)','Umum',NULL,'pcs',0,5,110000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(523,'SPR26030513','SIL KRUK AS/ GENENG RINO 130HT 90311-99002 TYT (B)','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(524,'SPR26030514','SIL OLEKAN RINO','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(525,'SPR26030515','SIL OLEKAN RINO (KCL)','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(526,'SPR26030516','Sil oli shock DP futura','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(527,'SPR26030517','SIL PERSENELENG BLK 90311-48011 JPN','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(528,'SPR26030518','SIL PERSENELENG BLK CANTER 125PS','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(529,'SPR26030519','SIL PERSENELENG BLK CANTER 125PS MH034177 JPN','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(530,'SPR26030520','SIL PERSENELENG BLK RINO JPN','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(531,'SPR26030521','SIL PINION CANTER PS125','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(532,'SPR26030522','SIL PINION RINO 130HT BHS1900-AO','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(533,'SPR26030523','SIL POWER STEERING ME739102','Umum',NULL,'pcs',0,5,95000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(534,'SPR26030524','sil puli rino','Umum',NULL,'pcs',0,5,125000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(535,'SPR26030525','SIL PULLY RINO 130HT','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(536,'SPR26030526','sil puly canter ME017208 KTB','Umum',NULL,'pcs',0,5,175000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(537,'SPR26030527','Sil Puly Fuso','Umum',NULL,'pcs',0,5,0.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(538,'SPR26030528','sil puly ps100','Umum',NULL,'pcs',0,5,70000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(539,'SPR26030529','SIL RODA DALAM BLK CANTER','Umum',NULL,'pcs',0,5,115000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(540,'SPR26030530','SIL RODA DALAM BLK RINO 14B 90311-75003','Umum',NULL,'pcs',0,5,42500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(541,'SPR26030531','SIL RODA DLM BLK CANTER AD149-B0 (B)','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(542,'SPR26030532','SIL RODA DLM BLK CANTER AD149-B1','Umum',NULL,'pcs',0,5,17500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(543,'SPR26030533','SIL RODA DLM BLK Rino 130ht 11038','Umum',NULL,'pcs',0,5,27500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(544,'SPR26030534','SIL RODA DPN CANTER','Umum',NULL,'pcs',0,5,30500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(545,'SPR26030535','SIL RODA DPN ENGKEL','Umum',NULL,'pcs',0,5,22500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(546,'SPR26030536','SIL RODA DPN RINO 90311-68002','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(547,'SPR26030537','sil roda HDX in','Umum',NULL,'pcs',0,5,42500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(548,'SPR26030538','sil roda HDX out','Umum',NULL,'pcs',0,5,50000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(549,'SPR26030539','SIL RODA LUAR BLK CANTER MB161134 MMC JPN','Umum',NULL,'pcs',0,5,24000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(550,'SPR26030540','SIL RODA LUAR BLK CANTER MT420207 MMC (B)','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(551,'SPR26030541','SIL RODA LUAR BLK RINO 130HT','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(552,'SPR26030542','SIL RODA LUAR BLK RINO 130HT -40001','Umum',NULL,'pcs',0,5,8500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(553,'SPR26030543','sil serpo booster canter110\\125 MR493229AL','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(554,'SPR26030544','SIL SHOCKBREKER SS','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(555,'SPR26030545','sil tc 18x35x8','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(556,'SPR26030546','sil tc 19x32x7','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(557,'SPR26030547','sil tc 20x10x7','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(558,'SPR26030548','sil tc 20x30x7','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(559,'SPR26030549','SIL TC 22x40x10','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(560,'SPR26030550','SIL TC 22X40X8 (SIL POMPA RINO)','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(561,'SPR26030551','SIL TC 25X35X8','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(562,'SPR26030552','sil tc 25x40x7','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(563,'SPR26030553','sil tc 25x40x8','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(564,'SPR26030554','sil tc 25x42x10','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(565,'SPR26030555','sil tc 25x45x10','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(566,'SPR26030556','sil tc 34x10x15x20','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(567,'SPR26030557','sil tc 34x6x15,5','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(568,'SPR26030558','sil tc 45x65x10','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(569,'SPR26030559','SIL TIMING COVER NKR71 ISUZU 897329780 IRM','Umum',NULL,'pcs',0,5,150000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(570,'SPR26030560','SIL TRANSMISI FUSO 58X75X9 TC','Umum',NULL,'pcs',0,5,20000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(571,'SPR26030561','SIL TRANSMISI RINO 48X33X8','Umum',NULL,'pcs',0,5,30000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(572,'SPR26030562','SKUN 10','Umum',NULL,'pcs',0,5,1500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(573,'SPR26030563','SKUN 12','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(574,'SPR26030564','SKUN 14','Umum',NULL,'pcs',0,5,2500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(575,'SPR26030565','SKUN 17','Umum',NULL,'pcs',0,5,2000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(576,'SPR26030566','SKUN AKI N70','Umum',NULL,'pcs',0,5,7500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(577,'SPR26030567','SLIP KRUK AS RINO 130HT OVERSIZE 100','Umum',NULL,'pcs',0,5,500000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(578,'SPR26030568','SOCKET LAMPU H4','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(579,'SPR26030569','SOCKET RILEY KAKI 4','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(580,'SPR26030570','SPAKBOR KIRI CANTER MK545175.','Umum',NULL,'pcs',0,5,60000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(581,'SPR26030571','SPI SINKRONIS CANTER ME-610061','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(582,'SPR26030572','STANG SPION DUTRO 931LL TYT(B)','Umum',NULL,'pcs',0,5,245000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(583,'SPR26030573','STICKER \"CANTER\" KM902617','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(584,'SPR26030574','STICKER \"GRV\" FUTURA RELVAN','Umum',NULL,'pcs',0,5,11000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(585,'SPR26030575','STICKER \"HD125PS\"','Umum',NULL,'pcs',0,5,10350.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(586,'SPR26030576','STICKER \"MITSUBISHI\" KM902571','Umum',NULL,'pcs',0,5,52000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(587,'SPR26030577','STICKER BODY L300 KM903316','Umum',NULL,'pcs',0,5,42300.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(588,'SPR26030578','STICKER COLT DIESEL KM902319','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(589,'SPR26030579','STICKER HDX 6.6 KM904769 KTB','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(590,'SPR26030580','STICKER PS125','Umum',NULL,'pcs',0,5,8640.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(591,'SPR26030581','STOPPER DEPAN CANTER MK631163 FUJINATA','Umum',NULL,'pcs',0,5,37500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(592,'SPR26030582','STOPPER DEPAN CANTER MK631166','Umum',NULL,'pcs',0,5,110000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(593,'SPR26030583','STOPPER DEPAN RINO 48304-36080 FUJINATA','Umum',NULL,'pcs',0,5,37500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(594,'SPR26030584','SWITCH BRAKE PEDAL GAS/ REM 125HT/130HT GEN JPN','Umum',NULL,'pcs',0,5,47500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(595,'SPR26030585','SWITCH BRAKE/ REM 84640-37050 TYT(B)','Umum',NULL,'pcs',0,5,62500.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(596,'SPR26030586','SWITCH REM RINO 130HT','Umum',NULL,'pcs',0,5,27000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(597,'SPR26030587','SYNCRO GIGI 3 RINO 130HT HINO (A) 33369-37020','Umum',NULL,'pcs',0,5,140000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(598,'SPR26030588','TALANG AIR CANTER','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(599,'SPR26030589','TALANG AIR DYNA RINO','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(600,'SPR26030590','TIE ROD CANTER SE-789 555','Umum',NULL,'pcs',0,5,215000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(601,'SPR26030591','TIE ROD OLEKAN BAUT 12','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(602,'SPR26030592','TIE ROD OLEKAN BAUT 14','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(603,'SPR26030593','tie rod ps 100 engkel se-7221r','Umum',NULL,'pcs',0,5,255000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(604,'SPR26030594','TIE ROD RINO SE-T231 555 (A)','Umum',NULL,'pcs',0,5,225000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(605,'SPR26030595','TURN BAUD BLK CANTER','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(606,'SPR26030596','TURN BAUD BLK RINO','Umum',NULL,'pcs',0,5,22750.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(607,'SPR26030597','TURN BAUD DPN','Umum',NULL,'pcs',0,5,4000.00,0.00,NULL,NULL,'2026-03-28 03:38:58','2026-03-31 13:31:34',NULL,NULL,NULL),(608,'SPR26030598','TURN BAUD DPN CANTER','Umum',NULL,'pcs',0,5,4000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(609,'SPR26030599','TUTUP AS RODA CANTER MB-060563 SGW','Umum',NULL,'pcs',0,5,12000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(610,'SPR26030600','TUTUP AS RODA ENGKEL 1405/HUCA-M2000','Umum',NULL,'pcs',0,5,0.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(611,'SPR26030601','TUTUP AS RODA RINO 43514-37030 JAC','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(612,'SPR26030602','TUTUP AS RODA RINO 80141','Umum',NULL,'pcs',0,5,0.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(613,'SPR26030603','TUTUP PEMBUANGAN RADIATOR CANTER MC432744','Umum',NULL,'pcs',0,5,5750.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(614,'SPR26030604','TUTUP RADIATOR KCL DENSO 022510-1570 (B)','Umum',NULL,'pcs',0,5,12500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(615,'SPR26030605','TUTUP RADIATOR KCL DENSO JPN -1570','Umum',NULL,'pcs',0,5,45000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(616,'SPR26030606','TUTUP SPION BSR KANAN MK548652','Umum',NULL,'pcs',0,5,46500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(617,'SPR26030607','TUTUP STANG BWH SPION CANTER','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(618,'SPR26030608','TUTUP STANG SPION BSR CANTER L MK548651','Umum',NULL,'pcs',0,5,48150.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(619,'SPR26030609','TUTUP STANG SPION BULAT CANTER MK404988','Umum',NULL,'pcs',0,5,5000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(620,'SPR26030610','TUTUP STANG SPION SEGITIGA LH MK548654','Umum',NULL,'pcs',0,5,19300.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(621,'SPR26030611','TUTUP STANG SPION SEGITIGA RH MK548653','Umum',NULL,'pcs',0,5,10190.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(622,'SPR26030612','WATER OUTLET RINO 130HT','Umum',NULL,'pcs',0,5,115000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(623,'SPR26030613','WIPER LINK CANTER','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(624,'SPR26030614','WATER OUTLET CANTER 125PS ME224760 MIT (B)','Umum',NULL,'pcs',0,5,120000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(625,'SPR26030615','SIL PINION CANTER 125PS MC827472 NOK CTC','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(626,'SPR26030616','KARET REM FUSO/ PS190 BLK 80133','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(627,'SPR26030617','KARET REM FUSO/ PS190 DEPAN 80093','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(628,'SPR26030618','SAMBUNGAN FLEKSIBEL KNALPOT CANTER 125PS SUMA','Umum',NULL,'pcs',0,5,91000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(629,'SPR26030619','FLEKSIBEL KNALPOT CANTER 125PS SUMA','Umum',NULL,'pcs',0,5,197000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(630,'SPR26030620','KABEL MASSA AKI 24V','Umum',NULL,'pcs',0,5,31500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(631,'SPR26030621','BAUD KOPEL FUSO','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(632,'SPR26030622','BAUD GEARSET CANTER MH001989','Umum',NULL,'pcs',0,5,23500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(633,'SPR26030623','MUR GEARSET CANTER MH004171','Umum',NULL,'pcs',0,5,16000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(634,'SPR26030624','LAHER RODA DEPAN DLM CANTER 125PS 3720/ 3780 KOYO','Umum',NULL,'pcs',0,5,175000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(635,'SPR26030625','MUR PINION CANTER 125PS 13240-608H0 WAKASA','Umum',NULL,'pcs',0,5,70000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(636,'SPR26030626','BAUD AS CANTER  MH001488 KTB','Umum',NULL,'pcs',0,5,6000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(637,'SPR26030627','LAHER PTO 6205 KOYO','Umum',NULL,'pcs',0,5,40000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(638,'SPR26030628','LAHER PTO 6304 KOYO','Umum',NULL,'pcs',0,5,42000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(639,'SPR26030629','RAMBANG DEPAN DUTRO 130HD 53111-LAA40 HOP','Umum',NULL,'pcs',0,5,220000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(640,'SPR26030630','LAMPU DEPAN ASSY LH RINO 130HT 92001 CPU.','Umum',NULL,'pcs',0,5,385000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(641,'SPR26030631','TALANG AIR DUTRO','Umum',NULL,'pcs',0,5,100000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(642,'SPR26030632','TABUNG KNALPOT DUTRO 130HD','Umum',NULL,'pcs',0,5,690000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(643,'SPR26030633','DRAGLINK DUTRO 130HD 45440-39315 SH','Umum',NULL,'pcs',0,5,410000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(644,'SPR26030634','ORING PLUNGER RINO 130HT/CANTER DENSO 191051-5971A','Umum',NULL,'pcs',0,5,5800.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(645,'SPR26030635','BAN (DUTRO)','Umum',NULL,'pcs',0,5,461250.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(646,'SPR26030636','LAHER 6204 KOYO','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(647,'SPR26030637','BOHLAM H4 24V 75/70W PHILIPS','Umum',NULL,'pcs',0,5,42500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(648,'SPR26030638','PLUNGER RINO 130HD 090150-7653 ND (B)','Umum',NULL,'pcs',0,5,250000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(649,'SPR26030639','BAUD TUTUP KING PEN ATAS (TEBAL)','Umum',NULL,'pcs',0,5,65050.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(650,'SPR26030640','BAUD TUTUP KING PEN BAWAH (TIPIS)','Umum',NULL,'pcs',0,5,42500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(651,'SPR26030641','PIRODO HAND BRAKE SHOE K-015 KGW RINO','Umum',NULL,'pcs',0,5,85000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(652,'SPR26030642','BAUD NEPEL BUANGAN REM CANTER 125PS','Umum',NULL,'pcs',0,5,11000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(653,'SPR26030643','KUL STATER RINO 130HT JMTSX-56','Umum',NULL,'pcs',0,5,57500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(654,'SPR26030644','DUDUKAN MESIN/ MOUNTING RINO 130HT 12361-78110 IBK','Umum',NULL,'pcs',0,5,122500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(655,'SPR26030645','KARPET CERET DEPAN CANTER ENGKEL','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(656,'SPR26030646','KARET REM 7/8 RINO 546','Umum',NULL,'pcs',0,5,10000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(657,'SPR26030647','RING SEHER/PCS 0,50 CANTER 125PS ME996567 KTB','Umum',NULL,'pcs',0,5,315000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(658,'SPR26030648','BAUD SHOCKBREKER DPN RINO','Umum',NULL,'pcs',0,5,35000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34','2026-03-28 04:21:44',NULL,NULL),(659,'SPR26030649','KARET REM RINO -492','Umum',NULL,'pcs',0,5,80000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(660,'SPR26030650','KARET REM CANTER -253','Umum',NULL,'pcs',0,5,80000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(661,'SPR26030651','SIL PINION RINO TYT B','Umum',NULL,'pcs',0,5,37500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(662,'SPR26030652','PAKING TUTUP KLEP CANTER WTB','Umum',NULL,'pcs',0,5,24000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(663,'SPR26030653','HOLDER SUNVISOR CANTER MK405657','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(664,'SPR26030654','PLUG TUTUP HOLDER PLAFON CANTER MK405441','Umum',NULL,'pcs',0,5,6000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(665,'SPR26030655','BOSHING ARM L300','Umum',NULL,'pcs',0,5,15000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(666,'SPR26030656','BOSH RACK STIR FUTURA','Umum',NULL,'pcs',0,5,17000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(667,'SPR26030657','DUDUKAN KNALPOT BLK CANTER ME412957','Umum',NULL,'pcs',0,5,66750.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(668,'SPR26030658','TUTUP STANG SPION BSR CANTER R MK548652','Umum',NULL,'pcs',0,5,46500.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(669,'SPR26030659','KABEL PERS RINO PANJANG','Umum',NULL,'pcs',0,5,415000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(670,'SPR26030660','KABEL PERS RINO PENDEK','Umum',NULL,'pcs',0,5,360000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(671,'SPR26030661','KARET GANTUNGAN KNALPOT CANTER WAKASA','Umum',NULL,'pcs',0,5,25000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL),(672,'SPR26030662','RING SEHER STD CANTER ME996566','Umum',NULL,'pcs',0,5,1250000.00,0.00,NULL,NULL,'2026-03-28 03:38:59','2026-03-31 13:31:34',NULL,NULL,NULL);
/*!40000 ALTER TABLE `spare_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supir`
--

DROP TABLE IF EXISTS `supir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supir` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `telepon` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomor_sim` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_sim` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_bergabung` date NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `info_kendaraan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol_kendaraan` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `armada_default_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_supir_kode` (`kode`),
  KEY `ix_supir_nama` (`nama`),
  KEY `fk_supir_armada` (`armada_default_id`),
  CONSTRAINT `fk_supir_armada` FOREIGN KEY (`armada_default_id`) REFERENCES `armada_jasa_angkut` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supir`
--

LOCK TABLES `supir` WRITE;
/*!40000 ALTER TABLE `supir` DISABLE KEYS */;
INSERT INTO `supir` VALUES (1,'SPR26020001','M usa','-','Cianjur','-','-','B1','2026-02-09',1,'','2026-02-09 13:00:24','2026-02-09 13:00:24',NULL,NULL,NULL,NULL),(2,'SPR26020002','M DENDI','-','-','-','-','B1','2026-02-09',1,'','2026-02-09 15:54:37','2026-02-16 10:08:29',NULL,'Truk','F111Z',NULL);
/*!40000 ALTER TABLE `supir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `kota` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telepon` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `npwp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `bank` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rekening` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_suppliers_kode` (`kode`),
  KEY `ix_suppliers_nama` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'SUP26010001','Supplier Oli','Cianjur','Cianjur','0000','oli@gmail.com',NULL,NULL,NULL,'2026-01-31 11:03:28','2026-01-31 11:03:28',NULL,NULL,NULL),(2,'SUP26020001','Hshshsh','Cianjur ','Cianjur ','000000','ilham.taufiq@gmail.com',NULL,NULL,NULL,'2026-02-10 10:16:15','2026-02-10 10:16:15',NULL,NULL,NULL),(3,'SUP26020002','Tes','0000','Cianjur','0000',NULL,NULL,NULL,NULL,'2026-02-10 11:08:52','2026-02-10 11:08:52',NULL,NULL,NULL),(4,'SUP26020003','TOKO BALI','','CIANJUR','',NULL,NULL,NULL,NULL,'2026-02-10 11:37:28','2026-02-10 11:37:42',NULL,'',''),(5,'SUP26020004','SANGGAR','','BANDUNG','',NULL,NULL,NULL,NULL,'2026-02-11 10:42:26','2026-02-11 10:42:26',NULL,NULL,NULL),(6,'SUP26020005','KING MOTOR','BANDUNG','BANDUNG','',NULL,NULL,NULL,NULL,'2026-02-14 09:17:15','2026-02-14 09:17:25',NULL,'','');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_system_settings_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'smtp_config','{\"server\": \"smtp.gmail.com\", \"port\": 587, \"username\": \"your-email@gmail.com\", \"password\": \"your-app-password\", \"use_tls\": true, \"sender_name\": \"TPM Security\"}','SMTP configuration for sending OTP and password reset emails','2026-03-30 00:44:39','2026-03-30 00:44:39');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi_penjualan_bengkel`
--

DROP TABLE IF EXISTS `transaksi_penjualan_bengkel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi_penjualan_bengkel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `customer_id` int DEFAULT NULL,
  `nama_customer` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomor_plat` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_kendaraan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_parts` decimal(15,2) NOT NULL,
  `total_jasa` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `diskon` decimal(15,2) NOT NULL,
  `grand_total` decimal(15,2) NOT NULL,
  `hpp_parts` decimal(15,2) NOT NULL,
  `laba_kotor` decimal(15,2) NOT NULL,
  `status_bayar` enum('LUNAS','BELUM_LUNAS','CICILAN') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LUNAS',
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TUNAI',
  `jumlah_bayar` decimal(15,2) NOT NULL,
  `kembalian` decimal(15,2) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `status_pengerjaan` enum('ANTRE','PROSES','SELESAI','BATAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ANTRE',
  `kategori` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `muatan_id` int DEFAULT NULL,
  `mobil_id` int DEFAULT NULL,
  `armada_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_transaksi_penjualan_bengkel_nomor_transaksi` (`nomor_transaksi`),
  KEY `created_by` (`created_by`),
  KEY `customer_id` (`customer_id`),
  KEY `ix_transaksi_penjualan_bengkel_tanggal` (`tanggal`),
  KEY `ix_transaksi_penjualan_bengkel_status_pengerjaan` (`status_pengerjaan`),
  KEY `fk_bengkel_muatan` (`muatan_id`),
  KEY `fk_bengkel_mobil` (`mobil_id`),
  KEY `armada_id` (`armada_id`),
  CONSTRAINT `fk_bengkel_mobil` FOREIGN KEY (`mobil_id`) REFERENCES `mobil` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_bengkel_muatan` FOREIGN KEY (`muatan_id`) REFERENCES `muatan_jasa_angkut` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transaksi_penjualan_bengkel_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `transaksi_penjualan_bengkel_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `transaksi_penjualan_bengkel_ibfk_3` FOREIGN KEY (`armada_id`) REFERENCES `armada_jasa_angkut` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi_penjualan_bengkel`
--

LOCK TABLES `transaksi_penjualan_bengkel` WRITE;
/*!40000 ALTER TABLE `transaksi_penjualan_bengkel` DISABLE KEYS */;
INSERT INTO `transaksi_penjualan_bengkel` VALUES (112,'BGL2603310001','2026-03-31',6,'KWSG','W 1111 AA','RINO EURO 4',0.00,50000.00,50000.00,0.00,50000.00,0.00,50000.00,'LUNAS','KREDIT',50000.00,0.00,'',1,'2026-03-31 13:31:56','2026-03-31 13:32:11','ANTRE','umum',NULL,NULL,NULL);
/*!40000 ALTER TABLE `transaksi_penjualan_bengkel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi_penjualan_mobil`
--

DROP TABLE IF EXISTS `transaksi_penjualan_mobil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi_penjualan_mobil` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `mobil_id` int DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `nama_pembeli` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telepon_pembeli` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_pembeli` text COLLATE utf8mb4_unicode_ci,
  `harga_jual` decimal(15,2) NOT NULL,
  `total_modal` decimal(15,2) NOT NULL,
  `laba_kotor` decimal(15,2) NOT NULL,
  `tipe_kepemilikan` enum('TPM','INVESTOR') COLLATE utf8mb4_unicode_ci NOT NULL,
  `persentase_investor` decimal(5,2) NOT NULL,
  `laba_investor` decimal(15,2) NOT NULL,
  `laba_tpm` decimal(15,2) NOT NULL,
  `status_bayar` enum('LUNAS','BELUM_LUNAS','CICILAN','BATAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LUNAS',
  `metode_bayar` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TUNAI',
  `dp` decimal(15,2) NOT NULL,
  `sisa_bayar` decimal(15,2) NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `status_pencairan` enum('BELUM_DICAIRKAN','SEBAGIAN','DICAIRKAN') COLLATE utf8mb4_unicode_ci DEFAULT 'BELUM_DICAIRKAN',
  `tanggal_pencairan` date DEFAULT NULL,
  `nominal_pencairan` decimal(15,2) NOT NULL DEFAULT '0.00',
  `metode_pencairan` enum('TUNAI','TRANSFER','KREDIT','DEBIT','SPLIT','INTERNAL','POTONG_GAJI','OTHER') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_pencairan` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_transaksi_penjualan_mobil_nomor_transaksi` (`nomor_transaksi`),
  UNIQUE KEY `mobil_id` (`mobil_id`),
  KEY `created_by` (`created_by`),
  KEY `customer_id` (`customer_id`),
  KEY `ix_transaksi_penjualan_mobil_tanggal` (`tanggal`),
  CONSTRAINT `transaksi_penjualan_mobil_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `transaksi_penjualan_mobil_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `transaksi_penjualan_mobil_ibfk_3` FOREIGN KEY (`mobil_id`) REFERENCES `mobil` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi_penjualan_mobil`
--

LOCK TABLES `transaksi_penjualan_mobil` WRITE;
/*!40000 ALTER TABLE `transaksi_penjualan_mobil` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaksi_penjualan_mobil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_cash_adjustments`
--

DROP TABLE IF EXISTS `user_cash_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_cash_adjustments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `admin_id` int NOT NULL,
  `saldo_sebelum` decimal(15,2) NOT NULL,
  `saldo_sesudah` decimal(15,2) NOT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_user_cash_adjustments_admin_id` (`admin_id`),
  KEY `ix_user_cash_adjustments_user_id` (`user_id`),
  CONSTRAINT `user_cash_adjustments_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_cash_adjustments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_cash_adjustments`
--

LOCK TABLES `user_cash_adjustments` WRITE;
/*!40000 ALTER TABLE `user_cash_adjustments` DISABLE KEYS */;
INSERT INTO `user_cash_adjustments` VALUES (1,1,4,0.00,500000.00,500000.00,'','2026-03-18 14:03:58','2026-03-18 14:03:58'),(2,1,4,500000.00,520000.00,20000.00,'','2026-03-18 14:06:21','2026-03-18 14:06:21'),(3,1,4,520000.00,470000.00,-50000.00,'','2026-03-18 14:07:05','2026-03-18 14:07:05'),(4,1,4,470000.00,500000.00,30000.00,'','2026-03-18 14:09:13','2026-03-18 14:09:13'),(5,1,4,500000.00,550000.00,50000.00,'','2026-03-18 14:12:23','2026-03-18 14:12:23'),(6,1,4,550000.00,20000.00,-530000.00,'Managemen Saldo oleh Admin','2026-03-18 14:12:37','2026-03-18 14:12:37');
/*!40000 ALTER TABLE `user_cash_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashed_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('ADMIN','MANAGER','KASIR','MEKANIK','STAFF','VIEWER','BENGKEL','JASA_ANGKUT','MOBIL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STAFF',
  `is_active` tinyint(1) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `profile_picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hashed_pin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_settings` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `home_background` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`email`),
  UNIQUE KEY `ix_users_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@tpm.com','$2b$12$WZgNC7UyAGSC4Wp9gaYq4u1hTqCZqcppHthiMu6QCQZ/9OZUo0c5i','Administrator TPM','ADMIN',1,'2026-03-30 22:41:54','2026-01-31 09:01:24','2026-03-30 22:41:53','/uploads/avatar_1_e6d22557a2694ce18f5122bdaa916468.jpeg',NULL,'{\"app_lock\": true, \"finance\": true, \"bengkel\": true, \"jasa_angkut\": true, \"laporan\": true, \"master_data\": true, \"mobil\": true, \"sdm\": true, \"settings\": true}','081234567890',20000.00,NULL,NULL,'/uploads/bg_1_cdb87dcf330f4843ba7c9e7668ac25b0.jpg',NULL,NULL),(2,'manager','manager@tpm.com','$2b$12$oBl/wROS29lra2q3gU5uDOoZe0APw2KmIm40Vjxe4Fje4b67aKZ3G','Manager Toko','MANAGER',1,NULL,'2026-01-31 09:01:24','2026-01-31 09:01:24',NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL),(3,'staff','staff@tpm.com','$2b$12$hx.oRma3j./mKHHKzpj57uwNlDR.mmPT1wSkadJegAMsxh2yXj61q','Staff Operasional','STAFF',1,NULL,'2026-01-31 09:01:24','2026-03-30 01:05:29',NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,'318284','2026-03-30 01:15:30'),(4,'ilhamtopiq','ilhamtaufiq@gmail.com','$2b$12$kWpZA7XHaBUi8aiq8zjNOuUQ80RFwLSJ9FzNyqmF8RVgnujz626Yu','Ilham Taufiq','ADMIN',1,'2026-03-17 15:53:23','2026-03-17 22:50:40','2026-03-17 22:53:23',NULL,NULL,NULL,'',0.00,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-31 22:08:02
